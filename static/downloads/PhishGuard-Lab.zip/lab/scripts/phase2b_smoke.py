"""Real JWT/RBAC checks and one benign text report; no token/password output."""
import argparse
from getpass import getpass
import json
from pathlib import Path
import sys
import time
from urllib.error import HTTPError
from urllib.request import Request, urlopen
import uuid

import boto3
from botocore.exceptions import BotoCoreError, ClientError

ROOT = Path(__file__).resolve().parents[1]


def call(base, method, path, token=None, payload=None):
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = "Bearer " + token
    request = Request(base.rstrip("/") + path, method=method, headers=headers,
        data=json.dumps(payload).encode() if payload is not None else None)
    try:
        with urlopen(request, timeout=30) as result:
            return result.status, json.loads(result.read())
    except HTTPError as exc:
        try:
            return exc.code, json.loads(exc.read())
        finally:
            exc.close()


def check(condition, name):
    if not condition:
        raise ValueError(name + ": FAIL")
    print(name + ": PASS")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", default="phishguard")
    parser.add_argument("--stack-name", default="phishguard-ai")
    args = parser.parse_args()
    session = boto3.Session(profile_name=args.profile, region_name="us-east-1")
    stack = session.client("cloudformation").describe_stacks(StackName=args.stack_name)["Stacks"][0]
    outputs = {v["OutputKey"]: v["OutputValue"] for v in stack["Outputs"]}
    base, client_id = outputs["HttpApiEndpoint"], outputs["UserPoolClientId"]
    status, data = call(base, "GET", "/api/incidents")
    check(status == 401, "UNAUTHENTICATED_401")
    tokens = {}
    for role, username in [("REPORTER", "demo-reporter"), ("SECOPS_ADMIN", "demo-secops-admin"), ("AUDITOR", "demo-auditor")]:
        password = getpass(f"Mật khẩu {username}: ")
        result = session.client("cognito-idp").initiate_auth(ClientId=client_id, AuthFlow="USER_PASSWORD_AUTH",
            AuthParameters={"USERNAME": username, "PASSWORD": password})
        del password
        if "AuthenticationResult" not in result:
            raise ValueError("Cognito yêu cầu challenge; hoàn tất thiết lập tài khoản trước")
        tokens[role] = result["AuthenticationResult"]["AccessToken"]
        status, data = call(base, "GET", "/api/incidents", tokens[role])
        check(status == 200, role + "_LIST_200")
    status, data = call(base, "GET", "/api/audit-logs", tokens["REPORTER"])
    check(status == 403, "REPORTER_AUDIT_403")
    status, data = call(base, "GET", "/api/incidents/INC-000000000000/raw-evidence-url", tokens["AUDITOR"])
    check(status == 403, "AUDITOR_RAW_EVIDENCE_403")
    status, data = call(base, "POST", "/api/incidents/INC-000000000000/decision", tokens["AUDITOR"], {})
    check(status == 403, "AUDITOR_DECISION_403")
    idem = uuid.uuid4().hex
    payload = {"text": "Ngân hàng không yêu cầu cung cấp OTP hoặc mật khẩu.", "idempotency_key": idem}
    status, data = call(base, "POST", "/api/reports", tokens["REPORTER"], payload)
    check(status == 202 and "incident_id" in data, "REPORT_ACCEPTED_202")
    identifier = data["incident_id"]
    status, duplicate = call(base, "POST", "/api/reports", tokens["REPORTER"], payload)
    check(status == 202 and duplicate.get("incident_id") == identifier, "REPORT_IDEMPOTENCY")
    changed = dict(payload, text="Nội dung khác dùng lại cùng khóa.")
    status, data = call(base, "POST", "/api/reports", tokens["REPORTER"], changed)
    check(status == 409, "REUSED_KEY_DIFFERENT_CONTENT_409")
    final = None
    for attempt in range(30):
        status, data = call(base, "GET", "/api/incidents/" + identifier, tokens["REPORTER"])
        check(status == 200, "REPORTER_OWN_INCIDENT_200") if attempt == 0 else None
        check(not {"sfn_task_token", "raw_s3_key", "sfn_execution_arn"} & set(data), "INTERNAL_FIELDS_HIDDEN") if attempt == 0 else None
        if data.get("status") in {"NO_ACTION", "FAILED", "NEEDS_MORE_INFO", "PENDING_APPROVAL", "NEEDS_REVIEW"}:
            final = data
            break
        time.sleep(2)
    check(final is not None and final.get("status") == "NO_ACTION", "BENIGN_REPORT_NO_ACTION")
    check(final["policy_evaluation"]["risk_score"] == 0, "BENIGN_SCORE_ZERO")
    print("GATE: PHASE_2B_SMOKE_PASS")
    print("Chặng này kiểm chứng JWT/RBAC và pipeline văn bản; 15 ca kiểm thử đầy đủ được thực hiện ở chặng H.")
    return 0


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        raise SystemExit(main())
    except (OSError, ValueError, BotoCoreError, ClientError) as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        raise SystemExit(1)
