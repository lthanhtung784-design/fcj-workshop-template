"""Read-only check of top-three Knowledge Base results for two analyst questions."""
import argparse
import json
import boto3

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--kb", required=True)
    parser.add_argument("--profile", default="phishguard")
    parser.add_argument("--region", default="us-east-1")
    args = parser.parse_args()
    client = boto3.Session(profile_name=args.profile, region_name=args.region).client("bedrock-agent-runtime")
    cases = [
        ("H05", "Email chuyển tiếp, Return-Path khác From. Giải thích INDETERMINATE và cách xác minh thư gốc.", "04-email-chuyen-tiep-va-dmarc.txt"),
        ("H11", "Báo cáo HIGH nhưng không có mục tiêu hành động hợp lệ. SecOps làm gì ở NEEDS_REVIEW?", "05-high-thieu-muc-tieu.txt"),
    ]
    for case, question, expected in cases:
        result = client.retrieve(knowledgeBaseId=args.kb, retrievalQuery={"text": question},
                                 retrievalConfiguration={"vectorSearchConfiguration": {"numberOfResults": 3}})
        names = [item.get("location", {}).get("s3Location", {}).get("uri", "").rsplit("/", 1)[-1]
                 for item in result.get("retrievalResults", [])]
        print(json.dumps({"case": case, "top_3": names, "expected_document_in_top_3": expected in names}))

if __name__ == "__main__":
    main()
