"""Verify the deployed presigned upload, evidence handoff, and OCR branches."""
import argparse
from base64 import b64decode
import hashlib
import json
from pathlib import Path
import re
import struct
import sys
from time import monotonic, sleep
from urllib.error import HTTPError
from urllib.request import Request, urlopen
from uuid import uuid4
from xml.etree import ElementTree
import zlib

import boto3
from botocore.exceptions import BotoCoreError, ClientError

from phase2b_smoke import call, check
from verify_group2_samples import login, request, wait_incident


ROOT = Path(__file__).resolve().parents[1]
MAX_BYTES = 5 * 1024 * 1024
PNG_MAGIC = b"\x89PNG\r\n\x1a\n"
FINAL_STATES = {"NO_ACTION", "NEEDS_MORE_INFO", "NEEDS_REVIEW", "PENDING_APPROVAL", "ESCALATED_TIMEOUT"}


def blank_png():
    def chunk(kind, data):
        return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data))

    width = height = 512
    header = struct.pack(">IIBBBBB", width, height, 8, 0, 0, 0, 0)
    pixels = (b"\x00" + b"\xff" * width) * height
    return PNG_MAGIC + chunk(b"IHDR", header) + chunk(b"IDAT", zlib.compress(pixels)) + chunk(b"IEND", b"")


def upload_png(post, filename, content):
    boundary = uuid4().hex
    parts = []
    for key, value in post["fields"].items():
        parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{key}"\r\n\r\n{value}\r\n'.encode())
    parts += [
        f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{filename}"\r\n'
        'Content-Type: image/png\r\n\r\n'.encode(),
        content,
        f"\r\n--{boundary}--\r\n".encode(),
    ]
    upload = Request(post["url"], method="POST", data=b"".join(parts),
                     headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
    try:
        with urlopen(upload, timeout=30) as result:
            check(result.status in {200, 201, 204}, "S3_MULTIPART_POST")
    except HTTPError as exc:
        with exc:
            try:
                code = ElementTree.fromstring(exc.read(4096)).findtext("Code")
            except ElementTree.ParseError:
                code = None
        raise ValueError(f"S3_POST: HTTP {exc.code} ({code or 'UNEXPECTED_RESPONSE'})") from None


def verify_presign(base, reporter, filename, png):
    payload = {"filename": filename, "content_type": "image/png", "size": len(png)}
    session = request(base, reporter, "POST", "/api/uploads/presign", expected=201, payload=payload)
    identifier, upload_id = session["incident_id"], session["upload_id"]
    print(f"{filename}: {identifier}", flush=True)
    post = session["presigned_post"]
    fields = post["fields"]
    conditions = json.loads(b64decode(fields["policy"], validate=True))["conditions"]
    key = f"uploads/{upload_id}/raw"
    check(session.get("expires_in") == 300 and fields.get("key") == key
          and fields.get("Content-Type") == "image/png" and fields.get("x-amz-meta-incident-id") == identifier
          and {"key": key} in conditions and {"Content-Type": "image/png"} in conditions
          and ["content-length-range", 1, MAX_BYTES] in conditions, "PRESIGN_FIXED_KEY_TYPE_SIZE_AND_TTL")
    pending = request(base, reporter, "GET", f"/api/incidents/{identifier}")
    check(pending.get("status") == "UPLOAD_PENDING" and pending.get("reporter_identity_status") == "VERIFIED_JWT",
          "UPLOAD_SESSION_BOUND_TO_REPORTER")
    upload_png(post, filename, png)
    return identifier


def wait_readable(base, reporter, identifier):
    deadline = monotonic() + 360
    while monotonic() < deadline:
        item = request(base, reporter, "GET", f"/api/incidents/{identifier}")
        if item["status"] == "FAILED":
            raise ValueError(f"{identifier}: workflow FAILED.")
        if item["status"] in FINAL_STATES:
            return item
        sleep(2)
    raise ValueError(f"{identifier}: chưa thấy kết quả OCR sau 360 giây.")


def verify_handoff(states, workflow, identifier, png):
    execution_arn = workflow.replace(":stateMachine:", ":execution:", 1) + ":" + identifier
    # DescribeExecution may briefly lag the incident status read from DynamoDB.
    for attempt in range(5):
        try:
            execution = states.describe_execution(executionArn=execution_arn)
            break
        except ClientError as exc:
            if exc.response["Error"]["Code"] != "ExecutionDoesNotExist" or attempt == 4:
                raise
            sleep(1)
    payload = json.loads(execution["input"])
    check(execution.get("name") == identifier and payload.get("incident_id") == identifier
          and payload.get("raw_s3_key") == f"evidence/{identifier}/raw"
          and payload.get("evidence_sha256") == hashlib.sha256(png).hexdigest(), "INGEST_EVIDENCE_SHA256_AND_EXECUTION")


def verify_email_headers(base, reporter, identifier):
    if not re.fullmatch(r"INC-[0-9a-f]{12}", identifier):
        raise ValueError("ID mẫu email cần có dạng INC-xxxxxxxxxxxx.")
    item = request(base, reporter, "GET", f"/api/incidents/{identifier}")
    auth = item.get("email_auth", {})
    headers = auth.get("claimed_headers", {})
    required = {"from_domain", "from_user", "reply_to_domain", "reply_to_user"}
    allowed = required | {"return_path_domain", "return_path_user"}
    check(auth.get("source") == "EMBEDDED_UNVERIFIED" and auth.get("result") == "INDETERMINATE"
          and required <= headers.keys() <= allowed
          and all(re.fullmatch(r"EMAIL_USER_[1-9]\d*" if field.endswith("_user") else r"[a-z0-9.-]+", value)
                  for field, value in headers.items()), f"EML_HEADERS_REDACTED {identifier}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", default="phishguard")
    parser.add_argument("--stack-name", default="phishguard-ai")
    parser.add_argument("--email-incident", action="append", default=[], help="Existing sample-2 or sample-3 incident ID.")
    args = parser.parse_args()
    sample = (ROOT / "fixtures" / "intake" / "sample-01.png").read_bytes()
    if not sample.startswith(PNG_MAGIC) or len(sample) > MAX_BYTES:
        raise ValueError("Cần dùng file fixtures/intake/sample-01.png đã có trong gói 2B.")
    if not sys.stdin.isatty():
        raise ValueError("Chạy script trong terminal PowerShell để nhập mật khẩu ẩn.")

    aws = boto3.Session(profile_name=args.profile, region_name="us-east-1")
    stack = aws.client("cloudformation").describe_stacks(StackName=args.stack_name)["Stacks"][0]
    outputs = {entry["OutputKey"]: entry["OutputValue"] for entry in stack["Outputs"]}
    base = outputs["HttpApiEndpoint"]
    reporter = login(aws.client("cognito-idp"), outputs["UserPoolClientId"], "demo-reporter")
    for identifier in args.email_incident:
        verify_email_headers(base, reporter, identifier)

    status, body = call(base, "POST", "/api/uploads/presign", reporter,
                        {"filename": "size-check.png", "content_type": "image/png", "size": MAX_BYTES + 1})
    check(status == 400 and body.get("error") == "INVALID_UPLOAD_SIZE_OR_TYPE", "PRESIGN_OVER_5_MIB_REJECTED")

    # The first two POSTs fit the configured 2 rps / burst 5 defaults.
    states = aws.client("stepfunctions")
    identifier = verify_presign(base, reporter, "sample-01.png", sample)
    readable = wait_readable(base, reporter, identifier)
    verify_handoff(states, outputs["WorkflowArn"], identifier, sample)
    print(f"{identifier}: {readable['status']} OCR={readable.get('ocr_quality')}")

    blank = blank_png()
    identifier = verify_presign(base, reporter, "blank-ocr.png", blank)
    unreadable = wait_incident(base, reporter, identifier, "NEEDS_MORE_INFO", {"UPLOAD_PENDING", "NEW", "TRIAGING"}, 120)
    verify_handoff(states, outputs["WorkflowArn"], identifier, blank)
    check(unreadable.get("ocr_quality", {}).get("acceptable") is False, "BLANK_IMAGE_NEEDS_MORE_INFO")
    check(readable.get("ocr_quality", {}).get("acceptable") is True, "SAMPLE_1_OCR_ACCEPTABLE")
    print("GATE: GROUP1_PRESIGN_AND_OCR_PASS")
    return 0


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        raise SystemExit(main())
    except ClientError as exc:
        print(f"ERROR: {exc.operation_name}: {exc.response['Error']['Code']}", file=sys.stderr)
        raise SystemExit(1) from None
    except (OSError, BotoCoreError, KeyError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1) from None
