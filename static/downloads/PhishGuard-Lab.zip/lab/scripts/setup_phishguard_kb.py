"""Create or reuse PhishGuard's Bedrock KB, sync its playbooks, and verify Retrieve."""
import argparse
from hashlib import sha256
import sys
from time import monotonic, sleep

import boto3
from botocore.exceptions import BotoCoreError, ClientError


REGION = "us-east-1"
KB_NAME = "phishguard-kb"
ROLE_NAME = "AmazonBedrockExecutionRoleForKnowledgeBase_PhishGuard"
INDEX_NAME = "playbooks"
SOURCE_PREFIX = "playbooks/"
DIMENSIONS = 1024
METADATA_KEYS = {"AMAZON_BEDROCK_TEXT", "AMAZON_BEDROCK_METADATA"}


def list_items(client, operation, key, **parameters):
    for page in client.get_paginator(operation).paginate(**parameters):
        yield from page.get(key, [])


def creation_token(*parts):
    return sha256("\n".join(parts).encode("utf-8")).hexdigest()


def wait_for_status(label, resource, read, target, pending, seconds):
    deadline = monotonic() + seconds
    previous = None
    while True:
        status = resource["status"]
        if status != previous:
            print(f"{label}: {status}", flush=True)
            previous = status
        if status == target:
            return resource
        if status not in pending:
            reasons = "; ".join(resource.get("failureReasons", []))
            raise ValueError(f"{label}: {status}. {reasons}".strip())
        if monotonic() >= deadline:
            raise TimeoutError(f"{label} is still {status}. Run this script again to resume.")
        sleep(5)
        resource = read()


def select_knowledge_base(agent, role_arn, index_arn, model_arn):
    matches = []
    bucket_arn, _, index_name = index_arn.partition("/index/")
    for summary in list_items(agent, "list_knowledge_bases", "knowledgeBaseSummaries"):
        if summary["status"] == "FAILED":
            continue
        knowledge_base = agent.get_knowledge_base(knowledgeBaseId=summary["knowledgeBaseId"])["knowledgeBase"]
        vectors = knowledge_base.get("storageConfiguration", {}).get("s3VectorsConfiguration", {})
        stored_arn = vectors.get("indexArn")
        if not stored_arn and vectors.get("vectorBucketArn") and vectors.get("indexName"):
            stored_arn = f"{vectors['vectorBucketArn']}/index/{vectors['indexName']}"
        if stored_arn == index_arn:
            matches.append(knowledge_base)
        elif knowledge_base["name"] == KB_NAME:
            raise ValueError(f"{KB_NAME} already points to a different index ({knowledge_base['knowledgeBaseId']}).")

    if len(matches) > 1:
        ids = ", ".join(item["knowledgeBaseId"] for item in matches)
        raise ValueError(f"Multiple knowledge bases use {INDEX_NAME}: {ids}. Inspect them before syncing.")
    if matches:
        existing = matches[0]
        configuration = existing["knowledgeBaseConfiguration"]
        vector = configuration.get("vectorKnowledgeBaseConfiguration", {})
        embedding = vector.get("embeddingModelConfiguration", {}).get("bedrockEmbeddingModelConfiguration", {})
        if (existing["roleArn"] != role_arn or configuration["type"] != "VECTOR"
                or vector.get("embeddingModelArn") != model_arn or embedding.get("dimensions", DIMENSIONS) != DIMENSIONS
                or embedding.get("embeddingDataType", "FLOAT32") != "FLOAT32"):
            raise ValueError(f"KB {existing['knowledgeBaseId']} uses this index with a different role or embedding configuration.")
        print(f"KNOWLEDGE_BASE: REUSED {existing['knowledgeBaseId']}", flush=True)
        return existing

    created = agent.create_knowledge_base(
        clientToken=creation_token(KB_NAME, role_arn, index_arn, model_arn),
        name=KB_NAME,
        description="PhishGuard AI v2.2 SecOps playbooks",
        roleArn=role_arn,
        knowledgeBaseConfiguration={
            "type": "VECTOR",
            "vectorKnowledgeBaseConfiguration": {
                "embeddingModelArn": model_arn,
                "embeddingModelConfiguration": {
                    "bedrockEmbeddingModelConfiguration": {
                        "dimensions": DIMENSIONS,
                        "embeddingDataType": "FLOAT32",
                    },
                },
            },
        },
        storageConfiguration={
            "type": "S3_VECTORS",
            "s3VectorsConfiguration": {"vectorBucketArn": bucket_arn, "indexName": index_name},
        },
    )["knowledgeBase"]
    print(f"KNOWLEDGE_BASE: CREATED {created['knowledgeBaseId']}", flush=True)
    return created


def select_data_source(agent, kb_id, bucket_arn):
    matches = []
    for summary in list_items(agent, "list_data_sources", "dataSourceSummaries", knowledgeBaseId=kb_id):
        source_id = summary["dataSourceId"]
        source = agent.get_data_source(knowledgeBaseId=kb_id, dataSourceId=source_id)["dataSource"]
        configuration = source["dataSourceConfiguration"]
        s3 = configuration.get("s3Configuration", {})
        if configuration["type"] == "S3" and s3.get("bucketArn") == bucket_arn:
            prefixes = s3.get("inclusionPrefixes") or []
            if prefixes == [SOURCE_PREFIX]:
                matches.append(source)
            elif not prefixes or any(SOURCE_PREFIX.startswith(prefix) or prefix.startswith(SOURCE_PREFIX) for prefix in prefixes):
                raise ValueError(f"Data source {source_id} overlaps {bucket_arn}/{SOURCE_PREFIX}. Check its inclusion prefix.")

    if len(matches) > 1:
        raise ValueError(f"KB {kb_id} has several data sources for {bucket_arn}/{SOURCE_PREFIX}.")
    if matches:
        existing = matches[0]
        print(f"DATA_SOURCE: REUSED {existing['dataSourceId']}", flush=True)
        return existing

    created = agent.create_data_source(
        clientToken=creation_token(kb_id, bucket_arn, SOURCE_PREFIX),
        knowledgeBaseId=kb_id,
        name="phishguard-playbooks",
        dataSourceConfiguration={
            "type": "S3",
            "s3Configuration": {"bucketArn": bucket_arn, "inclusionPrefixes": [SOURCE_PREFIX]},
        },
    )["dataSource"]
    print(f"DATA_SOURCE: CREATED {created['dataSourceId']}", flush=True)
    return created


def sync_source(agent, kb_id, source_id):
    parameters = {"knowledgeBaseId": kb_id, "dataSourceId": source_id}
    pending = {"STARTING", "IN_PROGRESS", "STOPPING"}

    def running_job():
        response = agent.list_ingestion_jobs(
            **parameters, sortBy={"attribute": "STARTED_AT", "order": "DESCENDING"}, maxResults=5,
        )
        return next((job for job in response.get("ingestionJobSummaries", []) if job["status"] in pending), None)

    job = running_job()
    if job is None:
        try:
            job = agent.start_ingestion_job(**parameters)["ingestionJob"]
        except ClientError as exc:
            if exc.response["Error"]["Code"] != "ConflictException":
                raise
            job = running_job()
            if job is None:
                raise

    job_id = job["ingestionJobId"]
    result = wait_for_status(
        f"SYNC {job_id}", job,
        lambda: agent.get_ingestion_job(**parameters, ingestionJobId=job_id)["ingestionJob"],
        "COMPLETE", pending, 900,
    )
    failed = result.get("statistics", {}).get("numberOfDocumentsFailed", 0)
    if failed:
        raise ValueError(f"Sync reported {failed} failed document(s). See ingestion job {job_id} for details.")


def verify_retrieval(runtime, kb_id, source_uri):
    deadline = monotonic() + 120
    while True:
        response = runtime.retrieve(
            knowledgeBaseId=kb_id,
            retrievalQuery={"text": "Quy trình xác minh yêu cầu đổi tài khoản nhận tiền và báo cáo lừa đảo"},
            retrievalConfiguration={"vectorSearchConfiguration": {"numberOfResults": 3}},
        )
        uris = {
            result.get("location", {}).get("s3Location", {}).get("uri", "")
            for result in response.get("retrievalResults", [])
            if result.get("content", {}).get("text", "").strip()
        }
        playbooks = sorted(uri for uri in uris if uri.startswith(source_uri))
        if playbooks:
            for uri in playbooks:
                print(f"RETRIEVE: {uri}", flush=True)
            return
        if monotonic() >= deadline:
            raise ValueError(f"Retrieve returned no text from {source_uri}. Check the three files and the sync results.")
        sleep(5)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", default="phishguard")
    args = parser.parse_args()
    session = boto3.Session(profile_name=args.profile, region_name=REGION)
    identity = session.client("sts").get_caller_identity()
    account = identity["Account"]
    partition = identity["Arn"].split(":")[1]
    bucket = f"phishguard-kb-docs-{account}-{REGION}"
    vector_bucket = f"phishguard-kb-vectors-{account}-{REGION}"
    index_arn = f"arn:{partition}:s3vectors:{REGION}:{account}:bucket/{vector_bucket}/index/{INDEX_NAME}"
    model_arn = f"arn:{partition}:bedrock:{REGION}::foundation-model/amazon.titan-embed-text-v2:0"

    index = session.client("s3vectors").get_index(indexArn=index_arn)["index"]
    keys = index.get("metadataConfiguration", {}).get("nonFilterableMetadataKeys", [])
    if index["dimension"] != DIMENSIONS or index["dataType"] != "float32" or not METADATA_KEYS.issubset(keys):
        raise ValueError(f"Vector index {index_arn} differs from the PhishGuard 1024-dimensional index configuration.")
    role_arn = session.client("iam").get_role(RoleName=ROLE_NAME)["Role"]["Arn"]
    print(f"VECTOR_INDEX: {index_arn}", flush=True)

    agent = session.client("bedrock-agent")
    kb = select_knowledge_base(agent, role_arn, index_arn, model_arn)
    kb_id = kb["knowledgeBaseId"]
    wait_for_status(
        f"KB {kb_id}", kb, lambda: agent.get_knowledge_base(knowledgeBaseId=kb_id)["knowledgeBase"],
        "ACTIVE", {"CREATING", "UPDATING"}, 360,
    )
    source = select_data_source(agent, kb_id, f"arn:{partition}:s3:::{bucket}")
    source_id = source["dataSourceId"]
    wait_for_status(
        f"DATA_SOURCE {source_id}", source,
        lambda: agent.get_data_source(knowledgeBaseId=kb_id, dataSourceId=source_id)["dataSource"],
        "AVAILABLE", {"CREATING", "UPDATING"}, 360,
    )
    sync_source(agent, kb_id, source_id)
    print("RETRIEVE: querying the indexed playbooks", flush=True)
    verify_retrieval(session.client("bedrock-agent-runtime"), kb_id, f"s3://{bucket}/{SOURCE_PREFIX}")
    print(f"KnowledgeBaseId={kb_id}", flush=True)
    print("GATE: PHISHGUARD_KB_RETRIEVE_PASS", flush=True)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
    try:
        main()
    except ClientError as exc:
        error = exc.response["Error"]
        print(f"ERROR: {exc.operation_name}: {error['Code']}: {error.get('Message', '')}", file=sys.stderr)
        raise SystemExit(1) from None
    except (BotoCoreError, OSError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1) from None
