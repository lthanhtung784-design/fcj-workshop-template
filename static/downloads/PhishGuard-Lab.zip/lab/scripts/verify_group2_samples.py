"""Verify sample-2 DRY_RUN and sample-3 injection using the deployed HTTP API."""
import argparse
from getpass import getpass
import sys
from time import monotonic, sleep
from urllib.parse import urlencode
from uuid import uuid4

import boto3
from botocore.exceptions import BotoCoreError, ClientError

from phase2b_smoke import call


TARGET = "techc0mbank-vn.com"
ACTIVE_SOURCES = {"SEED", "APPROVED_CONFIRMED"}
BASE_RULES = {"BRAND_LOOKALIKE_DOMAIN", "FINANCIAL_OR_OTP_REQUEST", "HEADER_ANOMALY"}


def login(cognito, client_id, username):
    response = cognito.initiate_auth(
        ClientId=client_id,
        AuthFlow="USER_PASSWORD_AUTH",
        AuthParameters={"USERNAME": username, "PASSWORD": getpass(f"Mật khẩu {username}: ")},
    )
    token = response.get("AuthenticationResult", {}).get("AccessToken")
    if not token:
        raise ValueError(f"Cognito yêu cầu hoàn tất đăng nhập cho {username}.")
    return token


def request(base, token, method, path, expected=200, payload=None):
    status, body = call(base, method, path, token, payload)
    if status != expected:
        code = body.get("error", "UNEXPECTED_RESPONSE") if isinstance(body, dict) else "UNEXPECTED_RESPONSE"
        raise ValueError(f"{method} {path.split('?')[0]}: HTTP {status} ({code})")
    return body


def wait_incident(base, token, incident_id, expected, intermediate, seconds):
    deadline = monotonic() + seconds
    previous = None
    while monotonic() < deadline:
        item = request(base, token, "GET", f"/api/incidents/{incident_id}")
        status = item["status"]
        if status != previous:
            print(f"{incident_id}: {status}", flush=True)
        if status == expected:
            return item
        if status not in intermediate:
            raise ValueError(f"{incident_id}: cần {expected}, nhận {status}.")
        previous = status
        sleep(2)
    raise ValueError(f"{incident_id}: chưa tới {expected} sau {seconds} giây (cuối: {previous}).")


def find_row(base, admin, path, matches):
    cursor = None
    while True:
        query = "?" + urlencode({"next_token": cursor}) if cursor else ""
        page = request(base, admin, "GET", path + query)
        row = next((row for row in page["items"] if matches(row)), None)
        cursor = page.get("next_token")
        if row is not None or not cursor:
            return row
        sleep(0.15)


def submit_sample(base, reporter, sample_id):
    submitted = request(base, reporter, "POST", "/api/reports", expected=202, payload={
        "sample_id": sample_id, "idempotency_key": uuid4().hex,
    })
    identifier = submitted["incident_id"]
    print(f"{sample_id}: {identifier}", flush=True)
    item = wait_incident(base, reporter, identifier, "PENDING_APPROVAL",
                         {"UPLOAD_PENDING", "NEW", "TRIAGING", "TRIAGED"}, 360)
    policy = item["policy_evaluation"]
    rules = set(policy["triggered_rules"])
    expected_score = 100 if "KNOWN_BLOCKED_IOC" in rules else 80
    if (rules - {"KNOWN_BLOCKED_IOC"} != BASE_RULES or policy["risk_score"] != expected_score
            or policy["severity"] != "CRITICAL"):
        raise ValueError(f"{sample_id}: điểm hoặc luật khác dự kiến: {policy}.")
    print(f"{sample_id}: {policy['severity']} {policy['risk_score']}/100")
    return item


def verify_dry_run(base, reporter, admin):
    def matches_target(row):
        return row.get("ioc_value") == TARGET

    original = find_row(base, admin, "/api/blocklist", matches_target)
    protected_source = (original or {}).get("source")
    sample = submit_sample(base, reporter, "sample-2")
    identifier = sample["incident_id"]
    action = next((action for action in sample["proposed_actions"]
                   if action["type"] == "BLOCK_DOMAIN" and action["target"] == TARGET), None)
    if not action or action["mode"] != "DRY_RUN":
        raise ValueError(f"{identifier}: cần đề xuất BLOCK_DOMAIN cho mẫu ở chế độ DRY_RUN.")

    decision_id = uuid4().hex
    request(base, admin, "POST", f"/api/incidents/{identifier}/decision", payload={
        "decision_id": decision_id,
        "action_id": action["action_id"],
        "proposal_version": action["proposal_version"],
        "decision": "APPROVE",
        "note": "Group 2 sample-2 DRY_RUN verification",
    })
    wait_incident(base, reporter, identifier, "SIMULATED", {"PENDING_APPROVAL", "ACTION_REQUESTED"}, 90)

    def expected_blocklist(row):
        if not matches_target(row):
            return False
        if protected_source in ACTIVE_SOURCES:
            return row.get("source") == protected_source
        return row.get("source") == "APPROVED_DRY_RUN" and row.get("incident_id") == identifier

    def expected_audit(row):
        return (row.get("incident_id") == identifier and row.get("decision_id") == decision_id
                and row.get("action") == "APPROVE" and row.get("actor_role") == "SECOPS_ADMIN"
                and row.get("containment_mode") == "DRY_RUN" and row.get("new_status") == "SIMULATED")

    # These API list endpoints use DynamoDB scans with eventual consistency.
    for _ in range(6):
        blocked = find_row(base, admin, "/api/blocklist", expected_blocklist)
        audit = find_row(base, admin, "/api/audit-logs", expected_audit)
        if blocked and audit:
            print(f"sample-2: BLOCKLIST={blocked['source']} AUDIT={audit['action']}")
            print("GATE: SAMPLE_2_DRY_RUN_PASS")
            return
        sleep(2)
    raise ValueError(f"{identifier}: đã SIMULATED, chưa thấy Blocklist hoặc audit khớp quyết định {decision_id}.")


def verify_injection(base, reporter):
    sample = submit_sample(base, reporter, "sample-3")
    if "PROMPT_INJECTION_DETECTED" not in sample.get("security_flags", []):
        raise ValueError(f"{sample['incident_id']}: thiếu cờ PROMPT_INJECTION_DETECTED.")
    print("GATE: SAMPLE_3_TRIAGE_PASS (PROMPT_INJECTION_DETECTED)")
    synthesis = sample.get("agent_synthesis", {})
    status, reason = synthesis.get("status"), synthesis.get("fallback_reason")
    if reason == "GUARDRAIL_PROMPT_ATTACK":
        outcome = "DETECTED"
    elif reason == "GUARDRAIL_INTERVENED":
        outcome = "INTERVENED"
    elif reason == "RAG_OR_GUARDRAIL_NOT_CONFIGURED":
        outcome = "SKIPPED"
    elif status == "OK":
        outcome = "NO_INTERVENTION"
    else:
        outcome = "UNVERIFIED"
    print(f"SAMPLE_3_GUARDRAIL: {outcome} (synthesis={status}, reason={reason or 'none'})")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", default="phishguard")
    parser.add_argument("--stack-name", default="phishguard-ai")
    parser.add_argument("--sample", choices=("sample-2", "sample-3"), help="Verify just one sample.")
    args = parser.parse_args()

    session = boto3.Session(profile_name=args.profile, region_name="us-east-1")
    stack = session.client("cloudformation").describe_stacks(StackName=args.stack_name)["Stacks"][0]
    outputs = {item["OutputKey"]: item["OutputValue"] for item in stack.get("Outputs", [])}
    base, client_id = outputs.get("HttpApiEndpoint"), outputs.get("UserPoolClientId")
    if not base or not client_id:
        raise ValueError("Stack cần có HttpApiEndpoint và UserPoolClientId.")
    run_dry_run = args.sample != "sample-3"
    if run_dry_run and outputs.get("ConfiguredContainmentMode") != "DRY_RUN":
        raise ValueError("Cần ConfiguredContainmentMode=DRY_RUN để chạy kiểm thử duyệt sample-2.")
    if not sys.stdin.isatty():
        raise ValueError("Chạy script trong terminal PowerShell để nhập mật khẩu ẩn.")

    cognito = session.client("cognito-idp")
    reporter = login(cognito, client_id, "demo-reporter")
    if run_dry_run:
        admin = login(cognito, client_id, "demo-secops-admin")
        verify_dry_run(base, reporter, admin)
    if args.sample != "sample-2":
        verify_injection(base, reporter)
    return 0


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        raise SystemExit(main())
    except ClientError as exc:
        print(f"ERROR: {exc.operation_name}: {exc.response['Error']['Code']}", file=sys.stderr)
        raise SystemExit(1) from None
    except (OSError, BotoCoreError, KeyError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1) from None
