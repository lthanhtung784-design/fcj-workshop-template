// CloudFront Function (viewer-request), gắn vào behavior web mặc định.
// Giữ nguyên route API và asset; route SPA không có phần mở rộng về index.html.
function handler(event) {
  var request = event.request;
  var uri = request.uri;
  if (uri === "/api" || uri.indexOf("/api/") === 0) return request;
  var lastSegment = uri.substring(uri.lastIndexOf("/") + 1);
  if (lastSegment.indexOf(".") === -1) request.uri = "/index.html";
  return request;
}
