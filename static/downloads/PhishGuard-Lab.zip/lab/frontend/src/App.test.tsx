import { act, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import App from "./App";
import { api } from "./lib/api";
import { initializeAuth, mockUsers } from "./lib/auth";
import { incidentSchema } from "./types";

vi.mock("./config", () => ({ config: { useMock: false, region: "us-east-1" } }));
vi.mock("./lib/auth", async (importOriginal) => {
  const auth = await importOriginal<typeof import("./lib/auth")>();
  return { ...auth, initializeAuth: vi.fn() };
});
vi.mock("./lib/api", () => ({
  api: { incidents: vi.fn(), incident: vi.fn(), blocklist: vi.fn(), auditLogs: vi.fn() },
}));

const id = "INC-4d106209d30a";
const openIncidentButton = { name: `Mở ${id}` };
const reporter = mockUsers.REPORTER;
const safeText = "Máy in tầng hai đang được bảo trì.";

function finishedIncident() {
  return incidentSchema.parse({
    incident_id: id,
    created_at: new Date().toISOString(),
    status: "NO_ACTION",
    source_channel: "WEB_PORTAL",
    evidence_type: "TEXT",
    reporter_id: reporter.sub,
    sanitized_text: safeText,
    email_auth: { source: "NONE", result: "INDETERMINATE" },
  });
}

beforeEach(() => {
  vi.resetAllMocks();
  history.replaceState(null, "", "/");
  vi.mocked(initializeAuth).mockResolvedValue(reporter);
  vi.mocked(api.incidents).mockResolvedValue({ items: [finishedIncident()] });
  vi.mocked(api.incident).mockResolvedValue(finishedIncident());
  vi.mocked(api.blocklist).mockResolvedValue({ items: [] });
  vi.mocked(api.auditLogs).mockResolvedValue({ items: [] });
});

afterEach(() => {
  cleanup();
  vi.useRealTimers();
  vi.restoreAllMocks();
});

describe("Workspace navigation and refreshing", () => {
  it("closes and reopens incident details with Back and Forward in the same session", async () => {
    render(<App />);
    fireEvent.click(await screen.findByRole("button", openIncidentButton));
    expect(await screen.findByText(safeText)).toBeTruthy();
    expect(screen.queryByText("Xác thực email")).toBeNull();
    expect(new URLSearchParams(location.search).get("incident")).toBe(id);

    await act(async () => history.back());
    await waitFor(() => expect(screen.queryByRole("dialog")).toBeNull());
    expect(screen.getByRole("button", openIncidentButton)).toBeTruthy();

    await act(async () => history.forward());
    expect(await screen.findByRole("dialog")).toBeTruthy();
    await waitFor(() => expect(screen.getByText(safeText)).toBeTruthy());
    fireEvent.click(screen.getByRole("button", { name: "Đóng chi tiết" }));
    await waitFor(() => expect(screen.queryByRole("dialog")).toBeNull());
    expect(initializeAuth).toHaveBeenCalledTimes(1);
  });

  it("returns to the previous section on browser Back", async () => {
    vi.mocked(initializeAuth).mockResolvedValue(mockUsers.SECOPS_ADMIN);
    render(<App />);
    fireEvent.click(await screen.findByRole("button", { name: "Audit Logs" }));
    expect(screen.getByRole("heading", { level: 1, name: "Audit Logs" })).toBeTruthy();
    await act(async () => history.back());
    expect(await screen.findByRole("heading", { level: 1, name: "SecOps Queue" })).toBeTruthy();
    expect(initializeAuth).toHaveBeenCalledTimes(1);
  });

  it("refreshes the queue while work is in progress and stops at a terminal status", async () => {
    vi.useFakeTimers({ toFake: ["setInterval", "clearInterval"] });
    vi.spyOn(document, "visibilityState", "get").mockReturnValue("visible");
    const finished = finishedIncident();
    vi.mocked(api.incidents).mockResolvedValueOnce({
      items: [{ ...finished, status: "TRIAGING" }],
    });
    render(<App />);
    await screen.findByRole("button", openIncidentButton);
    expect(api.incidents).toHaveBeenCalledTimes(1);

    await act(async () => vi.advanceTimersByTimeAsync(5000));
    expect(api.incidents).toHaveBeenCalledTimes(2);
    await act(async () => vi.advanceTimersByTimeAsync(15000));
    expect(api.incidents).toHaveBeenCalledTimes(2);
    expect(screen.getByText("Không có đề xuất")).toBeTruthy();
  });

  it("keeps completed details idle and lets the user refresh them", async () => {
    vi.useFakeTimers({ toFake: ["setInterval", "clearInterval"] });
    vi.spyOn(document, "visibilityState", "get").mockReturnValue("visible");
    render(<App />);
    fireEvent.click(await screen.findByRole("button", openIncidentButton));
    await screen.findByText(safeText);
    await act(async () => vi.advanceTimersByTimeAsync(15000));
    expect(api.incidents).toHaveBeenCalledTimes(1);
    expect(api.incident).toHaveBeenCalledTimes(1);

    fireEvent.click(screen.getByRole("button", { name: "Làm mới chi tiết sự cố" }));
    await waitFor(() => expect(api.incident).toHaveBeenCalledTimes(2));
  });
});
