import React from "react";
import ReactDOM from "react-dom/client";
import "@fontsource-variable/inter";
import App from "./App";
import "./styles.css";

class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { failed: boolean }
> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  render() {
    return this.state.failed ? (
      <div className="auth-screen">
        <div className="login-card">
          <h1>Không thể hiển thị giao diện</h1>
          <p>Hãy tải lại trang. Dữ liệu mock đã lưu sẽ được giữ lại.</p>
          <button className="btn btn-primary" onClick={() => location.reload()}>
            Tải lại trang
          </button>
        </div>
      </div>
    ) : (
      this.props.children
    );
  }
}
ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </React.StrictMode>,
);
