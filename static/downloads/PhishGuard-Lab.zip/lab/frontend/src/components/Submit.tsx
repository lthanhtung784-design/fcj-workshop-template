import { useRef, useState } from "react";
import {
  ArrowRight,
  CheckCircle2,
  FileText,
  RefreshCw,
  Send,
  UploadCloud,
  X,
} from "lucide-react";
import { api } from "../lib/api";
import { config } from "../config";
import { explainError, newId, validateFile } from "../lib/security";
import type { Incident, PresignResponse, ReportRequest, User } from "../types";
import { demoDescriptions } from "../mock/fixtures";
import { Badge, ErrorNotice, Notice, Section } from "./ui";
import { IncidentTable } from "./Queue";

const fixtureDisplay = {
  DEMO_1: { title: "Zalo CEO Fraud", filename: "sample-01.png" },
  DEMO_2: { title: "Banking Lookalike .eml", filename: "sample-02.eml" },
  DEMO_3: { title: "Prompt Injection .eml", filename: "sample-03.eml" },
} satisfies Record<
  (typeof demoDescriptions)[number]["id"],
  {
    title: string;
    filename: string;
  }
>;

export function Submit({
  user,
  incidents,
  onCreated,
  onOpen,
}: {
  user: User;
  incidents: Incident[];
  onCreated: (id: string) => void;
  onOpen: (id: string) => void;
}) {
  const readOnly = user.role === "AUDITOR";
  const [tab, setTab] = useState<"text" | "file">("text");
  const [text, setText] = useState("");
  const [file, setFile] = useState<File>();
  const [dragging, setDragging] = useState(false);
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [key, setKey] = useState(() => newId("report_"));
  const [locked, setLocked] = useState(false);
  const inFlight = useRef(false);
  const reportDraft = useRef<ReportRequest>();
  const uploadSession = useRef<PresignResponse>();
  const demoDrafts = useRef<Record<string, ReportRequest>>({});
  const fileInput = useRef<HTMLInputElement>(null);
  const fresh = () => {
    reportDraft.current = undefined;
    uploadSession.current = undefined;
    setKey(newId("report_"));
    setLocked(false);
    setError("");
    setSuccess("");
  };
  const pick = (candidate?: File) => {
    if (!candidate) return;
    try {
      validateFile(candidate);
      setFile(candidate);
      setError("");
      uploadSession.current = undefined;
    } catch (e) {
      setFile(undefined);
      setError(explainError(e));
    }
  };
  const demo = async (id: "DEMO_1" | "DEMO_2" | "DEMO_3") => {
    if (inFlight.current || readOnly) return;
    inFlight.current = true;
    setBusy(id);
    setError("");
    setSuccess("");
    demoDrafts.current[id] ??= {
      report_type: "SAMPLE",
      sample_id: id,
      text_content: null,
      idempotency_key: newId("demo_"),
    };
    try {
      const r = await api.report(user, demoDrafts.current[id]);
      delete demoDrafts.current[id];
      setSuccess(r.incident_id);
      onCreated(r.incident_id);
    } catch (e) {
      setError(explainError(e));
    } finally {
      inFlight.current = false;
      setBusy("");
    }
  };
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (inFlight.current || readOnly) return;
    inFlight.current = true;
    setError("");
    setSuccess("");
    setBusy("form");
    try {
      let incidentId: string;
      if (tab === "text") {
        if (!text.trim()) throw new Error("Nhập nội dung cần kiểm tra.");
        reportDraft.current ??= {
          report_type: "TEXT",
          sample_id: null,
          text_content: text,
          idempotency_key: key,
        };
        setLocked(true);
        const result = await api.report(user, reportDraft.current);
        incidentId = result.incident_id;
      } else {
        if (!file) throw new Error("Chọn tệp cần báo cáo.");
        const metadata = validateFile(file);
        setLocked(true);
        uploadSession.current ??= await api.presign(user, metadata);
        await api.upload(user, uploadSession.current, file);
        incidentId = uploadSession.current.incident_id;
      }
      fresh();
      setText("");
      setFile(undefined);
      if (fileInput.current) fileInput.current.value = "";
      setSuccess(incidentId);
      onCreated(incidentId);
    } catch (e) {
      setError(explainError(e));
    } finally {
      inFlight.current = false;
      setBusy("");
    }
  };
  return (
    <div className="submit-page">
      {readOnly && (
        <Notice tone="blue">
          Auditor có quyền đọc. REPORTER và SECOPS_ADMIN có quyền gửi phân tích.
        </Notice>
      )}
      {error && <ErrorNotice message={error} />}
      {success && (
        <div className="success-notice" role="status">
          <CheckCircle2 size={20} />
          <div>
            <strong>Đã tiếp nhận báo cáo</strong>
            <p className="mono">{success}</p>
          </div>
          <button className="btn btn-primary" onClick={() => onOpen(success)}>
            Mở sự cố
            <ArrowRight size={15} />
          </button>
        </div>
      )}
      <div className="report-layout">
        <section className="panel report-form">
          <div className="panel-heading">
            <h2>Gửi báo cáo phishing</h2>
          </div>
          <div className="form-tabs" role="tablist" aria-label="Loại báo cáo">
            <button
              role="tab"
              aria-selected={tab === "text"}
              disabled={locked || !!busy}
              className={tab === "text" ? "active" : ""}
              onClick={() => setTab("text")}
            >
              <FileText size={15} />
              Dán văn bản / Raw Header
            </button>
            <button
              role="tab"
              aria-selected={tab === "file"}
              disabled={locked || !!busy}
              className={tab === "file" ? "active" : ""}
              onClick={() => setTab("file")}
            >
              <UploadCloud size={16} />
              Tải lên bằng chứng
            </button>
          </div>
          <form onSubmit={(e) => void submit(e)}>
            <fieldset disabled={readOnly || !!busy || locked}>
              {tab === "text" ? (
                <>
                  <label htmlFor="report-text" className="field-label">
                    Nội dung cần kiểm tra<span>*</span>
                  </label>
                  <textarea
                    id="report-text"
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    placeholder="Dán nội dung email, tin nhắn hoặc header gốc."
                    className="mono"
                    rows={8}
                    maxLength={50000}
                    required
                  />
                  <div className="textarea-footer">
                    {text.length.toLocaleString("vi-VN")} / 50.000
                  </div>
                  <div className="idempotency-field">
                    <label
                      htmlFor="idempotency-key"
                      className="field-label mono"
                    >
                      idempotency_key
                    </label>
                    <div className="input-action">
                      <input
                        id="idempotency-key"
                        className="field-input mono"
                        value={key}
                        onChange={(e) => setKey(e.target.value)}
                        minLength={8}
                        maxLength={64}
                        pattern="[A-Za-z0-9_-]{8,64}"
                        required
                      />
                      <button
                        type="button"
                        className="btn btn-secondary"
                        onClick={() => setKey(newId("report_"))}
                      >
                        <RefreshCw size={14} />
                        Tạo lại
                      </button>
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <input
                    ref={fileInput}
                    type="file"
                    className="sr-only"
                    aria-label="Chọn tệp báo cáo"
                    accept=".eml,.png,.jpg,.jpeg,.txt"
                    onChange={(e) => pick(e.target.files?.[0])}
                  />
                  <button
                    type="button"
                    className={`drop-zone ${dragging ? "dragging" : ""}`}
                    onClick={() => fileInput.current?.click()}
                    onDragOver={(e) => {
                      e.preventDefault();
                      setDragging(true);
                    }}
                    onDragLeave={() => setDragging(false)}
                    onDrop={(e) => {
                      e.preventDefault();
                      setDragging(false);
                      pick(e.dataTransfer.files[0]);
                    }}
                  >
                    <UploadCloud size={20} />
                    <strong>
                      Kéo thả tệp vào đây hoặc <span>chọn tệp</span>
                    </strong>
                    <p className="mono">
                      .eml, .png, .jpg, .jpeg, .txt · ≤ 5 MB
                    </p>
                    <p className="mono">Presigned POST</p>
                  </button>
                  {file && (
                    <div className="file-selected">
                      <FileText size={19} />
                      <div>
                        <strong>{file.name}</strong>
                        <p>{(file.size / 1024).toFixed(1)} KB</p>
                      </div>
                      <button
                        type="button"
                        className="icon-button"
                        aria-label="Bỏ chọn tệp"
                        onClick={() => setFile(undefined)}
                      >
                        <X size={16} />
                      </button>
                    </div>
                  )}
                  {config.useMock && (
                    <p className="helper-text">
                      Ảnh và EML MIME phức tạp chuyển sang NEEDS_MORE_INFO trong
                      chế độ mock.
                    </p>
                  )}
                </>
              )}
            </fieldset>
            <div className="form-submit-row">
              <button
                className="btn btn-primary"
                type="submit"
                disabled={
                  readOnly || !!busy || (tab === "text" ? !text.trim() : !file)
                }
              >
                {busy === "form" ? (
                  <span className="spinner" />
                ) : (
                  <Send size={15} />
                )}{" "}
                {locked ? "Gửi lại yêu cầu" : "Gửi phân tích"}
              </button>
            </div>
            {locked && !busy && (
              <div className="retry-info">
                <p>Gửi lại sử dụng cùng yêu cầu đã lưu.</p>
                <button type="button" className="text-button" onClick={fresh}>
                  Bắt đầu báo cáo mới
                </button>
              </div>
            )}
          </form>
        </section>
        <Section title="Standard Verification Fixtures">
          <ul className="fixture-list">
            {demoDescriptions.map((fixture) => (
              <li key={fixture.id} className="fixture-row">
                <div className="fixture-info">
                  <h3>
                    <code>{fixture.id}</code>:{" "}
                    {fixtureDisplay[fixture.id].title}
                  </h3>
                  <p className="mono">{fixtureDisplay[fixture.id].filename}</p>
                  <Badge
                    tone={fixture.severity === "CRITICAL" ? "red" : "amber"}
                  >
                    {fixture.score} pts · {fixture.severity}
                  </Badge>
                </div>
                <button
                  type="button"
                  className="btn btn-secondary btn-small"
                  disabled={!!busy || readOnly}
                  title={readOnly ? "Auditor có quyền đọc" : "Run Fixture"}
                  aria-label={`Chạy mẫu ${fixture.id}`}
                  onClick={() => void demo(fixture.id)}
                >
                  {busy === fixture.id ? (
                    <span className="spinner" />
                  ) : (
                    "Chạy mẫu"
                  )}
                </button>
              </li>
            ))}
          </ul>
        </Section>
      </div>
      {user.role === "REPORTER" && (
        <IncidentTable personal incidents={incidents} onOpen={onOpen} />
      )}
    </div>
  );
}
