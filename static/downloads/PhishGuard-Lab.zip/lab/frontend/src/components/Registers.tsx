import { useState } from "react";
import { Search } from "lucide-react";
import type { AuditEntry, BlockEntry } from "../types";
import { Badge, EmptyState, SafeText, dateTime } from "./ui";

export function Blocklist({
  items,
  onOpen,
}: {
  items: BlockEntry[];
  onOpen: (id: string) => void;
}) {
  const [search, setSearch] = useState("");
  const [source, setSource] = useState("ALL");
  const filtered = items.filter(
    (b) =>
      (source === "ALL" || b.source === source) &&
      [b.ioc_value, b.display_value, b.incident_id]
        .join(" ")
        .toLowerCase()
        .includes(search.toLowerCase()),
  );
  return (
    <section className="panel">
      <div className="table-toolbar">
        <label className="search-box">
          <Search size={17} />
          <input
            aria-label="Tìm IOC"
            placeholder="Tìm IOC hoặc mã sự cố…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </label>
        <select
          className="sort-select"
          aria-label="Nguồn Blocklist"
          value={source}
          onChange={(e) => setSource(e.target.value)}
        >
          <option value="ALL">Mọi nguồn</option>
          {["SEED", "APPROVED_CONFIRMED", "APPROVED_DRY_RUN"].map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>
      </div>
      <div className="table-scroll">
        <table className="data-table register-table">
          <thead>
            <tr>
              <th scope="col">Mã sự cố</th>
              <th scope="col">IOC canonical / defanged</th>
              <th scope="col">Nguồn</th>
              <th scope="col">Chế độ</th>
              <th scope="col">Người duyệt</th>
              <th scope="col">Tạo lúc (UTC)</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((b, i) => (
              <tr key={`${b.ioc_value}-${i}`}>
                <td>
                  {b.incident_id ? (
                    <button
                      className="table-link mono"
                      onClick={() => onOpen(b.incident_id!)}
                    >
                      {b.incident_id}
                    </button>
                  ) : (
                    <span className="muted">—</span>
                  )}
                </td>
                <td>
                  <span className="canonical-text mono">{b.ioc_value}</span>
                  <span className="cell-sub mono">
                    <SafeText value={b.display_value} />
                  </span>
                </td>
                <td>
                  <Badge
                    tone={b.source === "APPROVED_DRY_RUN" ? "blue" : "green"}
                  >
                    {b.source}
                  </Badge>
                </td>
                <td>
                  <span className="mono text-xs">{b.mode}</span>
                </td>
                <td>
                  <span className="mono">{b.approved_by || "—"}</span>
                </td>
                <td>
                  <span className="log-time mono">
                    {dateTime(b.created_at)}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {!filtered.length && <EmptyState title="Không tìm thấy IOC" />}
      <div className="table-footer">
        <span>{filtered.length} mục phù hợp</span>
        <span>
          SEED / APPROVED_CONFIRMED có hiệu lực · APPROVED_DRY_RUN chỉ mô phỏng
        </span>
      </div>
    </section>
  );
}
export function AuditLogs({
  items,
  onOpen,
}: {
  items: AuditEntry[];
  onOpen: (id: string) => void;
}) {
  const [search, setSearch] = useState("");
  const [action, setAction] = useState("ALL");
  const events = [
    ...new Set([
      "APPROVE",
      "REJECT",
      "TIMEOUT",
      "VIEW_RAW_EVIDENCE",
      ...items.map((a) => a.action),
    ]),
  ];
  const filtered = items.filter(
    (a) =>
      (action === "ALL" || a.action === action) &&
      [a.incident_id, a.actor_id, a.action, a.decision_note]
        .join(" ")
        .toLowerCase()
        .includes(search.toLowerCase()),
  );
  return (
    <section className="panel">
      <div className="table-toolbar">
        <label className="search-box">
          <Search size={17} />
          <input
            aria-label="Tìm audit log"
            placeholder="Tìm sự cố, người thực hiện hoặc ghi chú…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </label>
        <select
          className="sort-select"
          aria-label="Loại sự kiện audit"
          value={action}
          onChange={(e) => setAction(e.target.value)}
        >
          <option value="ALL">Mọi sự kiện</option>
          {events.map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>
      </div>
      <div className="table-scroll">
        <table className="data-table audit-table">
          <thead>
            <tr>
              <th scope="col">Mã sự cố</th>
              <th scope="col">Thời gian (UTC)</th>
              <th scope="col">Sự kiện</th>
              <th scope="col">Người thực hiện</th>
              <th scope="col">Chuyển trạng thái / ghi chú</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((a, i) => (
              <tr key={a.audit_id || `${a.timestamp}-${i}`}>
                <td>
                  <button
                    className="table-link mono"
                    onClick={() => onOpen(a.incident_id)}
                  >
                    {a.incident_id}
                  </button>
                  {a.containment_mode && (
                    <span className="cell-sub mono">{a.containment_mode}</span>
                  )}
                </td>
                <td>
                  <span className="log-time mono">{dateTime(a.timestamp)}</span>
                </td>
                <td>
                  <span className="event-label mono">{a.action}</span>
                </td>
                <td>
                  <span className="mono">{a.actor_id}</span>
                  <span className="cell-sub mono">{a.actor_role}</span>
                </td>
                <td>
                  <div className="audit-transition">
                    {a.previous_status || "—"} <span>→</span>{" "}
                    {a.new_status || "—"}
                  </div>
                  {a.decision_note && (
                    <p className="audit-note">
                      <SafeText value={a.decision_note} />
                    </p>
                  )}
                  {a.decision_id && (
                    <span className="cell-sub mono">{a.decision_id}</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {!filtered.length && <EmptyState title="Không tìm thấy sự kiện" />}
      <div className="table-footer">
        <span>{filtered.length} sự kiện phù hợp</span>
        <span>Append-only · Chỉ đọc</span>
      </div>
    </section>
  );
}
