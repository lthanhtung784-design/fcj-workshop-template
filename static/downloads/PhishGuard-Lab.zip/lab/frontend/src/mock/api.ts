import { config } from "../config";
import {
  incidentSchema,
  auditSchema,
  blockSchema,
  type Api,
  type AuditEntry,
  type DecisionRequest,
  type Incident,
  type PresignResponse,
  type ReportRequest,
  type User,
} from "../types";
import {
  ApiError,
  assertRole,
  defang,
  idempotencyPattern,
  newId,
  validateFile,
} from "../lib/security";
import { demoDescriptions, rule, sampleIncident, seededData } from "./fixtures";

export const MOCK_DB_KEY = "phishguard.mock.v2.2.1";
interface Database extends ReturnType<typeof seededData> {
  version: 1;
  requests: Record<string, { fingerprint: string; incident_id: string }>;
  uploads: Record<
    string,
    {
      owner: string;
      incident_id: string;
      filename: string;
      size: number;
      content_type: string;
      expires: number;
      completed: boolean;
    }
  >;
  workflows: Record<string, { ready: number; finalStatus: Incident["status"] }>;
}
const rawFiles = new Map<string, Blob>();
const seedIds = new Set(seededData().incidents.map((i) => i.incident_id));
const clone = <T>(value: T): T => JSON.parse(JSON.stringify(value)) as T;
let fallbackQueue: Promise<void> = Promise.resolve();
function readDb(): Database {
  try {
    const raw = localStorage.getItem(MOCK_DB_KEY);
    if (!raw) {
      const data: Database = {
        ...seededData(),
        version: 1,
        requests: {},
        uploads: {},
        workflows: {},
      };
      data.incidents
        .filter((i) => i.status === "PENDING_APPROVAL")
        .forEach((i) => {
          i.approval_expires_at = new Date(
            Date.now() + config.mockTimeoutSeconds * 1000,
          ).toISOString();
        });
      return data;
    }
    const d = JSON.parse(raw) as Database;
    if (d.version !== 1 || !d.requests || !d.uploads || !d.workflows)
      throw new Error();
    d.incidents = incidentSchema.array().parse(d.incidents);
    d.audit = auditSchema.array().parse(d.audit);
    d.blocklist = blockSchema.array().parse(d.blocklist);
    return d;
  } catch {
    throw new ApiError(
      500,
      "MOCK_DATA_INVALID",
      "Dữ liệu demo không đọc được. Xem hướng dẫn khởi tạo lại trong README.",
    );
  }
}
function audit(
  db: Database,
  entry: Omit<AuditEntry, "audit_id" | "timestamp">,
) {
  db.audit.unshift({
    ...entry,
    audit_id: newId("AUD-"),
    timestamp: new Date().toISOString(),
  });
}
function advance(db: Database) {
  for (const i of db.incidents) {
    const flow = db.workflows[i.incident_id];
    if (flow) {
      i.status = Date.now() >= flow.ready ? flow.finalStatus : "TRIAGING";
      if (Date.now() >= flow.ready) {
        if (i.status === "PENDING_APPROVAL")
          i.approval_expires_at = new Date(
            flow.ready + config.mockTimeoutSeconds * 1000,
          ).toISOString();
        delete db.workflows[i.incident_id];
      }
    }
    if (
      i.status === "PENDING_APPROVAL" &&
      i.approval_expires_at &&
      Date.parse(i.approval_expires_at) <= Date.now()
    ) {
      i.status = "ESCALATED_TIMEOUT";
      audit(db, {
        incident_id: i.incident_id,
        actor_id: "workflow",
        actor_role: "SYSTEM",
        action: "TIMEOUT",
        previous_status: "PENDING_APPROVAL",
        new_status: i.status,
        decision_note: "Phiên phê duyệt đã hết hạn. Không thực thi hành động.",
      });
    }
  }
}
async function transaction<T>(
  fn: (db: Database) => T | Promise<T>,
): Promise<T> {
  const work = async () => {
    const db = readDb();
    advance(db);
    // Persist advancement even if a late decision is subsequently rejected.
    try {
      localStorage.setItem(MOCK_DB_KEY, JSON.stringify(db));
    } catch {
      throw new ApiError(507, "STORAGE_FULL", "Không thể lưu demo.");
    }
    const result = await fn(db);
    try {
      localStorage.setItem(MOCK_DB_KEY, JSON.stringify(db));
    } catch {
      throw new ApiError(507, "STORAGE_FULL", "Không thể lưu demo.");
    }
    return clone(result);
  };
  if (navigator.locks)
    return navigator.locks.request("phishguard-mock-db", work);
  const result = fallbackQueue.then(work, work);
  fallbackQueue = result.then(
    () => undefined,
    () => undefined,
  );
  return result;
}
function find(db: Database, user: User, id: string) {
  const item = db.incidents.find((i) => i.incident_id === id);
  if (!item || (user.role === "REPORTER" && item.reporter_id !== user.sub))
    throw new ApiError(
      404,
      "NOT_FOUND",
      "Không tìm thấy sự cố trong phạm vi quyền của bạn.",
    );
  return item;
}
function redact(text: string) {
  const counts: Record<string, number> = {
    BANK: 0,
    PHONE: 0,
    CCCD: 0,
    OTP: 0,
    EMAIL: 0,
  };
  const memo = new Map<string, string>();
  const mask = (kind: string, value: string) => {
    const key = `${kind}:${value}`;
    if (!memo.has(key)) {
      counts[kind]++;
      memo.set(
        key,
        `[${kind === "BANK" ? "BANK_ACCOUNT" : kind}_${counts[kind]}]`,
      );
    }
    return memo.get(key)!;
  };
  let safe = text.replace(
    /\b([a-z0-9._%+-]+)@([a-z0-9.-]+\.[a-z]{2,})\b/gi,
    (_all, local: string, domain: string) =>
      `${mask("EMAIL", local).replaceAll(/[\[\]]/g, "")}@${domain}`,
  );
  safe = safe.replace(
    /((?:OTP|mã xác nhận|ma xac nhan)\s*[:=]?\s*)(\d{4,8})/gi,
    (_all, prefix: string, v: string) => prefix + mask("OTP", v),
  );
  safe = safe.replace(
    /((?:CCCD|CMND)\s*[:=]?\s*)(\d{9,12})/gi,
    (_all, prefix: string, v: string) => prefix + mask("CCCD", v),
  );
  safe = safe.replace(
    /((?:tài khoản|tai khoan|STK|số thẻ|so the)\s*[:=]?\s*)(\d[\d -]{5,24}\d)/gi,
    (_all, prefix: string, v: string) => prefix + mask("BANK", v),
  );
  safe = safe.replace(/(?:\+84|0)(?:[ .-]?\d){9}\b/g, (v) => mask("PHONE", v));
  return { text: defang(safe), counts };
}
function analyze(
  text: string,
  user: User,
  id: string,
  evidenceType = "TEXT",
): Incident {
  const safe = redact(text);
  const normalized = text
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replaceAll("đ", "d")
    .toLowerCase();
  const urls = [...text.matchAll(/https?:\/\/[^\s<>"']+/gi)]
    .map((m) => m[0])
    .slice(0, 20);
  const extracted = urls.flatMap((url) => {
    try {
      const host = new URL(url).hostname;
      return [
        {
          canonical_value: host,
          display_value: defang(url),
          is_lookalike: /techc0mbank|vietc0mbank|acb-online/.test(host),
        },
      ];
    } catch {
      return [];
    }
  });
  const sensitive =
    /otp|mat khau|chuyen (?:gap |khoan |tien)|tai khoan|xac thuc/.test(
      normalized,
    );
  const exec = /giam doc|tong giam doc|ceo/.test(normalized) && sensitive;
  const lookalike = extracted.some((u) => u.is_lookalike);
  const from = text
    .match(/^From:\s*(.*)$/im)?.[1]
    .match(/@([a-z0-9.-]+)/i)?.[1];
  const reply = text
    .match(/^Reply-To:\s*(.*)$/im)?.[1]
    .match(/@([a-z0-9.-]+)/i)?.[1];
  const mismatch = Boolean(from && reply && from !== reply);
  const rules = [];
  if (lookalike)
    rules.push(
      rule(
        "BRAND_LOOKALIKE_DOMAIN",
        40,
        "Tên miền có dấu hiệu giả mạo thương hiệu trong bộ mẫu demo.",
      ),
    );
  if (sensitive)
    rules.push(
      rule(
        "FINANCIAL_OR_OTP_REQUEST",
        30,
        "Có yêu cầu thông tin nhạy cảm hoặc giao dịch tài chính.",
      ),
    );
  if (exec)
    rules.push(
      rule("EXEC_IMPERSONATION", 25, "Tự xưng lãnh đạo kèm yêu cầu nhạy cảm."),
    );
  if (
    /khan cap|chuyen gap|ngay lap tuc|urgently|urgent|trong \d+ phut/.test(
      normalized,
    )
  )
    rules.push(
      rule("URGENCY_PRESSURE", 10, "Có ngôn ngữ gây áp lực thời gian."),
    );
  if (mismatch && (sensitive || extracted.length))
    rules.push(
      rule(
        "HEADER_ANOMALY",
        10,
        "Reply-To khác miền From khai báo và có yêu cầu nhạy cảm.",
      ),
    );
  const score = Math.min(
    100,
    rules.reduce((s, r) => s + (r.points ?? 0), 0),
  );
  const item = sampleIncident(exec ? "DEMO_1" : "DEMO_2", user, id);
  item.evidence_type = evidenceType;
  item.ocr_quality = null;
  item.security_flags =
    /ignore (?:all |previous )?instructions|set (?:risk )?score to 0|bo qua (?:moi )?(?:quy tac|luat)/.test(
      normalized,
    )
      ? ["PROMPT_INJECTION_DETECTED"]
      : [];
  item.policy_evaluation = {
    risk_score: score,
    severity:
      score >= 75
        ? "CRITICAL"
        : score >= 50
          ? "HIGH"
          : score >= 25
            ? "MEDIUM"
            : "LOW",
    triggered_rules: rules,
  };
  item.email_auth =
    evidenceType === "EML"
      ? {
          source: "EMBEDDED_UNVERIFIED",
          result: "INDETERMINATE",
          claimed_headers: from
            ? {
                from_domain: from,
                ...(reply ? { reply_to_domain: reply } : {}),
              }
            : {},
        }
      : { source: "NONE", result: "NOT_APPLICABLE", claimed_headers: {} };
  item.deterministic_findings = {
    sanitized_excerpt: safe.text.slice(0, 12000),
    redacted_counts: safe.counts,
    extracted_urls: extracted,
    header_signals: mismatch ? ["HEADER_REPLY_TO_MISMATCH"] : [],
  };
  item.proposed_actions = [];
  if (score >= 50 && lookalike) {
    const target = extracted.find((u) => u.is_lookalike)!;
    item.proposed_actions = [
      {
        action_id: "ACT-001",
        type: "BLOCK_DOMAIN",
        target: target.canonical_value,
        display_target: defang(target.canonical_value),
        mode: "DRY_RUN",
        proposal_version: 1,
        impact_description:
          "Mô phỏng ghi nhận tên miền trong danh sách nội bộ. Không chặn lưu lượng thực.",
      },
    ];
  } else if (score >= 50 && exec)
    item.proposed_actions = sampleIncident("DEMO_1", user, id).proposed_actions;
  item.requires_manual_review = score >= 50 && !item.proposed_actions.length;
  item.status = item.proposed_actions.length
    ? "PENDING_APPROVAL"
    : item.requires_manual_review
      ? "NEEDS_REVIEW"
      : "NO_ACTION";
  item.agent_synthesis = {
    status: "FALLBACK",
    summary_vi: `Tổng hợp tất định của mô phỏng: ${rules.length} luật được kích hoạt, ${score}/100 điểm. ${item.status === "NO_ACTION" ? "Không có đề xuất hành động trong mô phỏng; vẫn xác minh qua kênh chính thức khi còn nghi ngờ." : "Hãy kiểm tra bằng chứng và xác minh ngữ cảnh trước khi quyết định."}`,
    evidence_table: extracted.map((u) => ({
      artifact: "Liên kết trích xuất",
      value: u.display_value,
      assessment: u.is_lookalike
        ? "Có dấu hiệu giả mạo"
        : "Cần xác minh ngữ cảnh",
    })),
    employee_recommendations: [
      "Không cung cấp OTP hoặc thông tin đăng nhập qua tin nhắn.",
      "Xác minh yêu cầu qua kênh liên lạc chính thức đã biết.",
      "Giữ bằng chứng gốc và liên hệ SecOps nếu đã tương tác.",
    ],
    rag_citations: [],
  };
  return item;
}
async function digest(value: string) {
  return [
    ...new Uint8Array(
      await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value)),
    ),
  ]
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}
function queue(db: Database, item: Incident) {
  db.workflows[item.incident_id] = {
    ready: Date.now() + 1600,
    finalStatus: item.status,
  };
  item.status = "NEW";
  db.incidents.unshift(item);
}
function applyKnownIocs(db: Database, item: Incident) {
  const p = item.policy_evaluation;
  if (!p) return;
  const matched = item.deterministic_findings?.extracted_urls.find((u) =>
    db.blocklist.some(
      (b) =>
        b.ioc_value === u.canonical_value && b.source !== "APPROVED_DRY_RUN",
    ),
  );
  if (!matched) return;
  p.triggered_rules.unshift(
    rule(
      "KNOWN_BLOCKED_IOC",
      50,
      "IOC khớp danh sách nội bộ có hiệu lực. Mục DRY_RUN không tham gia đối chiếu.",
    ),
  );
  p.risk_score = Math.min(
    100,
    p.triggered_rules.reduce((sum, r) => sum + (r.points ?? 0), 0),
  );
  p.severity = p.risk_score >= 75 ? "CRITICAL" : "HIGH";
  item.proposed_actions = [
    {
      action_id: "ACT-001",
      type: "BLOCK_DOMAIN",
      target: matched.canonical_value,
      display_target: defang(matched.canonical_value),
      mode: "DRY_RUN",
      proposal_version: 1,
      impact_description:
        "Mô phỏng ghi nhận IOC đã biết. Không tác động lưu lượng thực.",
    },
  ];
  item.status = "PENDING_APPROVAL";
  item.requires_manual_review = false;
  if (item.agent_synthesis)
    item.agent_synthesis.summary_vi = `Tổng hợp tất định của mô phỏng: IOC trùng danh sách nội bộ có hiệu lực, ${p.risk_score}/100 điểm. Cần kiểm tra bằng chứng và phê duyệt trước mọi hành động.`;
}
function decisionMatches(a: DecisionRequest, b: DecisionRequest) {
  return (
    a.decision_id === b.decision_id &&
    a.action_id === b.action_id &&
    a.proposal_version === b.proposal_version &&
    a.decision === b.decision &&
    a.note === b.note
  );
}
export const mockApi: Api = {
  incidents: async (user) =>
    transaction((db) => ({
      items: db.incidents.filter(
        (i) => user.role !== "REPORTER" || i.reporter_id === user.sub,
      ),
    })),
  incident: async (user, id) => transaction((db) => find(db, user, id)),
  report: async (user, body: ReportRequest) => {
    assertRole(user.role, ["SECOPS_ADMIN", "REPORTER"]);
    if (!idempotencyPattern.test(body.idempotency_key))
      throw new ApiError(
        400,
        "INVALID_KEY",
        "Mã idempotency phải gồm 8–64 chữ, số, _ hoặc -.",
      );
    if (
      body.report_type === "TEXT" &&
      (!body.text_content.trim() || body.text_content.length > 50000)
    )
      throw new ApiError(
        400,
        "INVALID_TEXT",
        "Nội dung phải có 1–50.000 ký tự.",
      );
    if (
      body.report_type === "SAMPLE" &&
      !demoDescriptions.some((s) => s.id === body.sample_id)
    )
      throw new ApiError(400, "INVALID_SAMPLE", "Mẫu không tồn tại.");
    const source = `${body.report_type}#${user.sub}#${body.idempotency_key}`;
    const fingerprint = await digest(
      JSON.stringify([body.report_type, body.sample_id, body.text_content]),
    );
    const id = "INC-" + (await digest(source)).slice(0, 12).toUpperCase();
    return transaction((db) => {
      const old = db.requests[source];
      if (old && old.fingerprint !== fingerprint)
        throw new ApiError(
          409,
          "IDEMPOTENCY_KEY_REUSED",
          "Mã đã dùng cho nội dung khác.",
        );
      if (old)
        return {
          incident_id: old.incident_id,
          status: find(db, user, old.incident_id).status,
          source_intake_key: source,
        };
      const item =
        body.report_type === "SAMPLE"
          ? sampleIncident(body.sample_id, user, id)
          : analyze(body.text_content, user, id);
      if (body.report_type === "TEXT") applyKnownIocs(db, item);
      queue(db, item);
      db.requests[source] = { fingerprint, incident_id: id };
      rawFiles.set(
        id,
        new Blob(
          [
            body.report_type === "TEXT"
              ? body.text_content
              : demoDescriptions.find((d) => d.id === body.sample_id)!.text,
          ],
          { type: "text/plain" },
        ),
      );
      audit(db, {
        incident_id: id,
        actor_id: user.sub,
        actor_role: user.role,
        action: "REPORT_CREATED",
        new_status: "NEW",
      });
      return {
        incident_id: id,
        status: "NEW" as const,
        source_intake_key: source,
      };
    });
  },
  presign: async (user, body) => {
    assertRole(user.role, ["SECOPS_ADMIN", "REPORTER"]);
    validateFile({
      name: body.filename,
      size: body.size,
      type: body.content_type,
    });
    const uploadId = crypto.randomUUID();
    const id =
      "INC-" + (await digest(`WEB#${uploadId}`)).slice(0, 12).toUpperCase();
    return transaction((db) => {
      const item = sampleIncident("DEMO_2", user, id);
      item.status = "UPLOAD_PENDING";
      item.proposed_actions = [];
      item.policy_evaluation = null;
      item.agent_synthesis = null;
      item.email_auth = null;
      item.deterministic_findings = null;
      item.evidence_type = body.content_type.startsWith("image/")
        ? "IMAGE"
        : body.content_type === "message/rfc822"
          ? "EML"
          : "TEXT";
      db.incidents.unshift(item);
      db.uploads[uploadId] = {
        owner: user.sub,
        incident_id: id,
        filename: body.filename,
        size: body.size,
        content_type: body.content_type,
        expires: Date.now() + 300000,
        completed: false,
      };
      return {
        upload_id: uploadId,
        incident_id: id,
        status: "UPLOAD_PENDING" as const,
        presigned_post: {
          url: "https://mock-upload.invalid",
          fields: {
            key: `uploads/${uploadId}/raw`,
            "Content-Type": body.content_type,
            "x-amz-meta-upload-id": uploadId,
          },
        },
      };
    });
  },
  upload: async (user, session: PresignResponse, file) => {
    assertRole(user.role, ["SECOPS_ADMIN", "REPORTER"]);
    validateFile(file);
    const content =
      file.type.startsWith("image/") || /\.(png|jpe?g)$/i.test(file.name)
        ? null
        : await file.text();
    await transaction((db) => {
      const upload = db.uploads[session.upload_id];
      if (
        !upload ||
        upload.owner !== user.sub ||
        upload.incident_id !== session.incident_id
      )
        throw new ApiError(403, "FORBIDDEN", "Phiên upload không hợp lệ.");
      if (upload.completed) return true;
      if (upload.expires < Date.now())
        throw new ApiError(
          410,
          "UPLOAD_EXPIRED",
          "Phiên upload hết hạn. Bắt đầu báo cáo mới để lấy phiên khác.",
        );
      if (file.size !== upload.size || file.name !== upload.filename)
        throw new ApiError(400, "INVALID_FILE", "Tệp khác với phiên upload.");
      const image = upload.content_type.startsWith("image/");
      const complex =
        content !== null &&
        /Content-Transfer-Encoding:\s*(?:base64|quoted-printable)|multipart\//i.test(
          content,
        );
      const item = analyze(
        content || "",
        user,
        upload.incident_id,
        upload.content_type === "message/rfc822"
          ? "EML"
          : image
            ? "IMAGE"
            : "TEXT",
      );
      applyKnownIocs(db, item);
      if (image || complex) {
        item.status = "NEEDS_MORE_INFO";
        item.proposed_actions = [];
        item.policy_evaluation = null;
        item.agent_synthesis = null;
        item.deterministic_findings = null;
        item.ocr_quality = image
          ? {
              engine: "MOCK_UNAVAILABLE",
              avg_confidence: null,
              word_count: 0,
              status: "NEEDS_MORE_INFO",
            }
          : null;
      }
      db.incidents = db.incidents.filter(
        (i) => i.incident_id !== item.incident_id,
      );
      queue(db, item);
      upload.completed = true;
      rawFiles.set(item.incident_id, file);
      audit(db, {
        incident_id: item.incident_id,
        actor_id: user.sub,
        actor_role: user.role,
        action: "UPLOAD_COMPLETED",
        previous_status: "UPLOAD_PENDING",
        new_status: "NEW",
      });
      return true;
    });
  },
  decision: async (user, id, body) => {
    assertRole(user.role, ["SECOPS_ADMIN"]);
    return transaction((db) => {
      const item = find(db, user, id);
      if (item.status === "ESCALATED_TIMEOUT")
        throw new ApiError(409, "APPROVAL_EXPIRED", "Đã hết hạn.");
      if (item.approval_record) {
        if (decisionMatches(item.approval_record, body)) return item;
        throw new ApiError(
          409,
          "DECISION_CONFLICT",
          "Quyết định khác đã được ghi nhận.",
        );
      }
      const action = item.proposed_actions.find(
        (a) =>
          a.action_id === body.action_id &&
          a.proposal_version === body.proposal_version,
      );
      if (item.status !== "PENDING_APPROVAL" || !action)
        throw new ApiError(
          409,
          "DECISION_CONFLICT",
          "Đề xuất không còn hợp lệ.",
        );
      if (
        body.decision === "APPROVE" &&
        action.type === "BLOCK_DOMAIN" &&
        !item.deterministic_findings?.extracted_urls.some(
          (u) => u.canonical_value === action.target,
        )
      )
        throw new ApiError(
          409,
          "DECISION_CONFLICT",
          "Target không có trong bằng chứng.",
        );
      if (body.note.length > 2000)
        throw new ApiError(400, "INVALID_NOTE", "Ghi chú tối đa 2.000 ký tự.");
      item.approval_record = {
        ...body,
        actor_id: user.sub,
        decided_at: new Date().toISOString(),
        callback_sent: true,
      };
      item.status =
        body.decision === "REJECT"
          ? "REJECTED"
          : action.mode === "DRY_RUN"
            ? "SIMULATED"
            : "INTERNAL_LIST_UPDATED";
      if (body.decision === "APPROVE" && action.type === "BLOCK_DOMAIN") {
        const source =
          action.mode === "DRY_RUN"
            ? ("APPROVED_DRY_RUN" as const)
            : ("APPROVED_CONFIRMED" as const);
        const existing = db.blocklist.find(
          (b) => b.ioc_value === action.target,
        );
        const entry = {
          ioc_value: action.target,
          display_value: action.display_target,
          ioc_type: "DOMAIN",
          source,
          mode: action.mode,
          incident_id: id,
          approved_by: user.sub,
          created_at: new Date().toISOString(),
        };
        // DRY_RUN không ghi đè SEED / APPROVED_CONFIRMED có hiệu lực.
        if (!existing) db.blocklist.unshift(entry);
        else if (
          source === "APPROVED_CONFIRMED" ||
          existing.source === "APPROVED_DRY_RUN"
        )
          Object.assign(existing, entry);
      }
      audit(db, {
        incident_id: id,
        actor_id: user.sub,
        actor_role: user.role,
        action: body.decision,
        previous_status: "PENDING_APPROVAL",
        new_status: item.status,
        decision_id: body.decision_id,
        decision_note: body.note,
        containment_mode: action.mode,
      });
      return item;
    });
  },
  rawEvidence: async (user, id) => {
    assertRole(user.role, ["SECOPS_ADMIN"]);
    return transaction((db) => {
      const item = find(db, user, id);
      if (!rawFiles.has(id) && !seedIds.has(id))
        throw new ApiError(
          410,
          "MOCK_RAW_UNAVAILABLE",
          "Bằng chứng gốc mock chỉ giữ trong bộ nhớ phiên này. Sau khi tải lại trang, hãy gửi lại tệp hoặc nội dung để kiểm tra tải bằng chứng.",
        );
      audit(db, {
        incident_id: id,
        actor_id: user.sub,
        actor_role: user.role,
        action: "VIEW_RAW_EVIDENCE",
        previous_status: item.status,
        new_status: item.status,
        decision_note: "Cấp quyền tải bằng chứng gốc mô phỏng trong 60 giây.",
      });
      const fixture =
        rawFiles.get(id) ||
        new Blob(
          [
            "PHISHGUARD MOCK EVIDENCE — dữ liệu mô phỏng.\nKhông phải bằng chứng AWS.\n\n" +
              (item.security_flags.includes("PROMPT_INJECTION_DETECTED")
                ? demoDescriptions[2].text
                : item.evidence_type === "IMAGE"
                  ? demoDescriptions[0].text
                  : demoDescriptions[1].text),
          ],
          { type: "text/plain" },
        );
      return {
        presigned_url: URL.createObjectURL(
          new Blob([fixture], { type: "application/octet-stream" }),
        ),
        expires_in_seconds: 60,
        audit_event_recorded: true,
      };
    });
  },
  blocklist: async (user) => {
    assertRole(user.role, ["SECOPS_ADMIN", "AUDITOR"]);
    return transaction((db) => ({ items: db.blocklist }));
  },
  auditLogs: async (user) => {
    assertRole(user.role, ["SECOPS_ADMIN", "AUDITOR"]);
    return transaction((db) => ({ items: db.audit }));
  },
};
