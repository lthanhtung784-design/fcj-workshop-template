import { z } from "zod";

export const roles = ["REPORTER", "SECOPS_ADMIN", "AUDITOR"] as const;
export type Role = (typeof roles)[number];
export interface User {
  sub: string;
  name: string;
  email: string;
  role: Role;
}
export const statuses = [
  "UPLOAD_PENDING",
  "NEW",
  "TRIAGING",
  "TRIAGED",
  "NO_ACTION",
  "NEEDS_MORE_INFO",
  "NEEDS_REVIEW",
  "PENDING_APPROVAL",
  "REJECTED",
  "ESCALATED_TIMEOUT",
  "ACTION_REQUESTED",
  "SIMULATED",
  "INTERNAL_LIST_UPDATED",
  "CONTAINMENT_FAILED",
  "FAILED",
] as const;
export type Status = (typeof statuses)[number];
export const actionSchema = z.object({
  action_id: z.string(),
  type: z.enum(["BLOCK_DOMAIN", "FINANCE_VERIFICATION_ALERT"]),
  target: z.string(),
  display_target: z.string(),
  mode: z.enum(["DRY_RUN", "INTERNAL_LIST"]),
  proposal_version: z.number().int().positive(),
  impact_description: z.string().default(""),
});
export const approvalSchema = z.object({
  decision_id: z.string(),
  action_id: z.string(),
  proposal_version: z.number(),
  decision: z.enum(["APPROVE", "REJECT"]),
  note: z.string(),
  actor_id: z.string(),
  decided_at: z.string(),
  callback_sent: z.boolean().optional(),
});
export const incidentSchema = z.object({
  incident_id: z.string(),
  created_at: z.string(),
  updated_at: z.string().optional(),
  source_channel: z.string(),
  evidence_type: z.string(),
  reporter_id: z.string(),
  reporter_identity_status: z.string().default("VERIFIED_JWT"),
  status: z.enum(statuses),
  requires_manual_review: z.boolean().default(false),
  ocr_quality: z
    .object({
      engine: z.string(),
      avg_confidence: z.number().nullable(),
      word_count: z.number().optional(),
      normalized_chars: z.number().optional(),
      status: z.string(),
    })
    .nullish(),
  email_auth: z
    .object({
      source: z.string(),
      result: z.string(),
      claimed_headers: z.record(z.string(), z.string()).default({}),
    })
    .nullish(),
  deterministic_findings: z
    .object({
      sanitized_excerpt: z.string().default(""),
      sanitized_text: z.string().optional(),
      redacted_counts: z.record(z.string(), z.number()).default({}),
      extracted_urls: z
        .array(
          z.object({
            canonical_value: z.string(),
            display_value: z.string(),
            is_lookalike: z.boolean().optional(),
            impersonated_brand: z.string().nullish(),
          }),
        )
        .default([]),
      header_signals: z.array(z.string()).default([]),
    })
    .nullish(),
  sanitized_text: z.string().optional(),
  sanitized_text_truncated: z.boolean().optional(),
  security_flags: z.array(z.string()).default([]),
  policy_evaluation: z
    .object({
      risk_score: z.number().min(0).max(100),
      severity: z.enum(["LOW", "MEDIUM", "HIGH", "CRITICAL"]),
      triggered_rules: z
        .array(
          z.object({
            rule_id: z.string(),
            points: z.number().optional(),
            reason: z.string().optional(),
          }),
        )
        .default([]),
    })
    .nullish(),
  proposed_actions: z.array(actionSchema).default([]),
  agent_synthesis: z
    .object({
      status: z.enum(["OK", "FALLBACK"]),
      model_id: z.string().optional(),
      prompt_version: z.string().optional(),
      summary_vi: z.string(),
      evidence_table: z
        .array(
          z.object({
            artifact: z.string(),
            value: z.string(),
            assessment: z.string(),
          }),
        )
        .default([]),
      employee_recommendations: z.array(z.string()).default([]),
      rag_citations: z
        .array(
          z.object({
            doc_id: z.string(),
            title: z.string(),
            excerpt: z.string(),
          }),
        )
        .default([]),
    })
    .nullish(),
  approval_record: approvalSchema.nullish(),
  approval_expires_at: z.string().optional(),
});
export type Incident = z.infer<typeof incidentSchema>;
export type ProposedAction = z.infer<typeof actionSchema>;
export type DecisionRequest = Pick<
  z.infer<typeof approvalSchema>,
  "decision_id" | "action_id" | "proposal_version" | "decision" | "note"
>;
export const blockSchema = z.object({
  ioc_value: z.string(),
  display_value: z.string(),
  ioc_type: z.string().default("DOMAIN"),
  source: z.enum(["SEED", "APPROVED_CONFIRMED", "APPROVED_DRY_RUN"]),
  mode: z.enum(["DRY_RUN", "INTERNAL_LIST"]),
  incident_id: z.string().nullish(),
  approved_by: z.string().nullish(),
  created_at: z.string(),
});
export type BlockEntry = z.infer<typeof blockSchema>;
export const auditSchema = z.preprocess(
  (value: unknown) => {
    if (value && typeof value === "object") {
      const row = value as Record<string, unknown>;
      if (
        typeof row.timestamp !== "string" &&
        typeof row.timestamp_action === "string"
      )
        return { ...row, timestamp: row.timestamp_action.split("#")[0] };
    }
    return value;
  },
  z.object({
    timestamp_action: z.string().optional(),
    audit_id: z.string().optional(),
    incident_id: z.string(),
    timestamp: z.string(),
    actor_id: z.string(),
    actor_role: z.string(),
    action: z.string(),
    previous_status: z.string().nullish(),
    new_status: z.string().nullish(),
    decision_id: z.string().nullish(),
    decision_note: z.string().nullish(),
    containment_mode: z.string().nullish(),
  }),
);
export type AuditEntry = z.infer<typeof auditSchema>;
export type ReportRequest =
  | {
      report_type: "SAMPLE";
      sample_id: "DEMO_1" | "DEMO_2" | "DEMO_3";
      text_content: null;
      idempotency_key: string;
    }
  | {
      report_type: "TEXT";
      sample_id: null;
      text_content: string;
      idempotency_key: string;
    };
export interface ReportResponse {
  incident_id: string;
  status: Status;
  source_intake_key?: string;
}
export interface PresignRequest {
  filename: string;
  content_type: string;
  size: number;
}
export interface PresignResponse {
  upload_id: string;
  incident_id: string;
  status: "UPLOAD_PENDING";
  presigned_post: { url: string; fields: Record<string, string> };
}
export interface RawResponse {
  presigned_url: string;
  expires_in_seconds: number;
  audit_event_recorded: boolean;
}
export interface Page<T> {
  items: T[];
  next_token?: string;
}
export interface Api {
  incidents(user: User, nextToken?: string): Promise<Page<Incident>>;
  incident(user: User, id: string): Promise<Incident>;
  report(user: User, request: ReportRequest): Promise<ReportResponse>;
  presign(user: User, request: PresignRequest): Promise<PresignResponse>;
  upload(user: User, session: PresignResponse, file: File): Promise<void>;
  decision(
    user: User,
    id: string,
    request: DecisionRequest,
  ): Promise<Incident | void>;
  rawEvidence(user: User, id: string): Promise<RawResponse>;
  blocklist(user: User, nextToken?: string): Promise<Page<BlockEntry>>;
  auditLogs(user: User, nextToken?: string): Promise<Page<AuditEntry>>;
}
