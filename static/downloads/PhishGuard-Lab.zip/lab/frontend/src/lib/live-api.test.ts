import { beforeEach, describe, expect, it, vi } from "vitest";
import { liveApi } from "./live-api";
import { mockUsers } from "./auth";
import { sampleIncident } from "../mock/fixtures";
vi.mock("./auth", async (importOriginal) => {
  const actual = await importOriginal<typeof import("./auth")>();
  return {
    ...actual,
    accessToken: vi.fn(async () => "test-cognito-access-token"),
  };
});
const user = mockUsers.SECOPS_ADMIN;
beforeEach(() => {
  vi.unstubAllGlobals();
});
describe("live HTTP wire contract", () => {
  it("sends Lambda's text DTO and a Bearer access token to the same-origin API", async () => {
    const fetcher = vi.fn(
      async () =>
        new Response(
          JSON.stringify({
            incident_id: "INC-123",
            status: "UPLOAD_PENDING",
          }),
          { status: 202 },
        ),
    );
    vi.stubGlobal("fetch", fetcher);
    const body = {
      report_type: "TEXT" as const,
      sample_id: null,
      text_content: "Test report",
      idempotency_key: "text_key_01",
    };
    await expect(liveApi.report(user, body)).resolves.toEqual({
      incident_id: "INC-123",
      status: "UPLOAD_PENDING",
    });
    const [path, init] = fetcher.mock.calls[0] as unknown as [
      string,
      RequestInit,
    ];
    expect(path).toBe("/api/reports");
    expect(init.headers).toMatchObject({
      Authorization: "Bearer test-cognito-access-token",
    });
    expect(JSON.parse(String(init.body))).toEqual({
      text: "Test report",
      idempotency_key: "text_key_01",
    });
  });
  it("maps the demo button to the fixture id used by the Lambda", async () => {
    const fetcher = vi.fn(async (_path: string, _init?: RequestInit) =>
      Response.json({ incident_id: "INC-123", status: "UPLOAD_PENDING" }, { status: 202 }),
    );
    vi.stubGlobal("fetch", fetcher);
    await liveApi.report(user, {
      report_type: "SAMPLE",
      sample_id: "DEMO_3",
      text_content: null,
      idempotency_key: "demo_key_0003",
    });
    expect(JSON.parse(String(fetcher.mock.calls[0][1]?.body))).toEqual({
      sample_id: "sample-3",
      idempotency_key: "demo_key_0003",
    });
  });
  it("consumes the 201 presign response without a status attribute", async () => {
    vi.stubGlobal("fetch", vi.fn(async () =>
      Response.json({
        upload_id: "upload-id",
        incident_id: "INC-123",
        expires_in: 300,
        presigned_post: { url: "https://intake.s3.amazonaws.com/", fields: { key: "uploads/upload-id/raw" } },
      }, { status: 201 }),
    ));
    await expect(liveApi.presign(user, {
      filename: "demo.png", content_type: "image/png", size: 42,
    })).resolves.toMatchObject({ incident_id: "INC-123", status: "UPLOAD_PENDING" });
  });
  it("renders the fields returned by the current incident pipeline", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => Response.json({
      items: [{
        incident_id: "INC-123",
        created_at: "2026-11-17T02:29:14.886+00:00",
        source_channel: "WEB_PORTAL",
        evidence_type: "IMAGE",
        reporter_id: "reporter-sub",
        status: "PENDING_APPROVAL",
        ocr_quality: {
          engine: "Tesseract (vie+eng)",
          mean_confidence: 85.47,
          normalized_chars: 174,
          acceptable: true,
        },
        deterministic_findings: {
          urls: [],
          lookalike_domains: [],
          header_findings: [],
        },
        policy_evaluation: {
          severity: "HIGH", risk_score: 65, triggered_rules: ["EXEC_IMPERSONATION"],
        },
        proposed_actions: [{
          action_id: "ACT-001",
          type: "FINANCE_VERIFICATION_ALERT",
          target: "FINANCE",
          mode: "DRY_RUN",
          proposal_version: 1,
        }],
        agent_synthesis: {
          status: "OK",
          summary_vi: "Cần xác minh yêu cầu.",
          evidence_table: [{ rule_id: "EXEC_IMPERSONATION", evidence_vi: "Tự xưng giám đốc." }],
          rag_citations: [{
            source_id: "KB-1",
            text: "Xác thực qua kênh chính thức.",
            location: { type: "S3", s3Location: { uri: "s3://kb-docs/playbooks/finance.txt" } },
          }],
        },
        raw_s3_key: "evidence/sensitive",
      }],
    })));
    const [item] = (await liveApi.incidents(user)).items;
    expect(item.ocr_quality).toMatchObject({
      engine: "Tesseract (vie+eng)",
      avg_confidence: 85.47,
      normalized_chars: 174,
    });
    expect(item.policy_evaluation?.triggered_rules).toEqual([
      { rule_id: "EXEC_IMPERSONATION", reason: "Tự xưng giám đốc." },
    ]);
    expect(item.proposed_actions[0].display_target).toBe("FINANCE");
    expect(item.agent_synthesis?.rag_citations[0]).toMatchObject({
      doc_id: "KB-1",
      title: "finance.txt",
    });
    expect(item).not.toHaveProperty("raw_s3_key");
  });
  it("POSTs signed fields before the file without leaking JWT or manual Content-Type", async () => {
    const fetcher = vi.fn(async () => new Response(null, { status: 204 }));
    vi.stubGlobal("fetch", fetcher);
    const file = new File(["mail"], "a.eml");
    const fields = {
      key: "uploads/id/raw",
      "Content-Type": "message/rfc822",
      Policy: "signed-policy",
      "X-Amz-Signature": "signature",
    };
    await liveApi.upload(
      user,
      {
        upload_id: "id",
        incident_id: "INC-1",
        status: "UPLOAD_PENDING",
        presigned_post: { url: "https://intake.s3.amazonaws.com", fields },
      },
      file,
    );
    const [url, init] = fetcher.mock.calls[0] as unknown as [
      string,
      RequestInit,
    ];
    expect(url).toBe("https://intake.s3.amazonaws.com/");
    expect(init.headers).toBeUndefined();
    expect([...(init.body as FormData).keys()]).toEqual([
      ...Object.keys(fields),
      "file",
    ]);
    expect(init.credentials).toBe("omit");
  });
  it("propagates idempotency conflicts and requires audit confirmation for raw grants", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(
        async () =>
          new Response(
            JSON.stringify({ code: "IDEMPOTENCY_KEY_REUSED", message: "Used" }),
            { status: 409 },
          ),
      ),
    );
    await expect(
      liveApi.report(user, {
        report_type: "SAMPLE",
        sample_id: "DEMO_1",
        text_content: null,
        idempotency_key: "demo_key_0001",
      }),
    ).rejects.toMatchObject({ status: 409, code: "IDEMPOTENCY_KEY_REUSED" });
    vi.stubGlobal(
      "fetch",
      vi.fn(
        async () =>
          new Response(
            JSON.stringify({
              presigned_url: "https://bucket.s3.amazonaws.com/raw",
              expires_in_seconds: 60,
              audit_event_recorded: false,
            }),
          ),
      ),
    );
    await expect(liveApi.rawEvidence(user, "INC-1")).rejects.toMatchObject({
      code: "INVALID_RESPONSE",
    });
  });
  it("removes server-internal fields and defensively enforces reporter ownership", async () => {
    const own = sampleIncident("DEMO_2", mockUsers.REPORTER, "INC-OWN");
    const other = sampleIncident("DEMO_2", user, "INC-OTHER");
    vi.stubGlobal(
      "fetch",
      vi.fn(
        async () =>
          new Response(
            JSON.stringify({
              items: [{ ...own, sfn_task_token: "must-never-reach-ui" }, other],
              next_token: "page2",
            }),
          ),
      ),
    );
    const result = await liveApi.incidents(mockUsers.REPORTER);
    expect(result.items).toHaveLength(1);
    expect(result.next_token).toBe("page2");
    expect(result.items[0]).not.toHaveProperty("sfn_task_token");
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => new Response(JSON.stringify(other))),
    );
    await expect(
      liveApi.incident(mockUsers.REPORTER, other.incident_id),
    ).rejects.toMatchObject({ status: 403 });
  });
  it("accepts the audit timestamp_action key defined by the project spec", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(
        async () =>
          new Response(
            JSON.stringify({
              items: [
                {
                  incident_id: "INC-1",
                  timestamp_action: "2026-11-12T15:31:00Z#APPROVE",
                  actor_id: "admin",
                  actor_role: "SECOPS_ADMIN",
                  action: "APPROVE",
                  previous_status: "PENDING_APPROVAL",
                  new_status: "SIMULATED",
                },
              ],
            }),
          ),
      ),
    );
    const result = await liveApi.auditLogs(user);
    expect(result.items[0].timestamp).toBe("2026-11-12T15:31:00Z");
  });
});
