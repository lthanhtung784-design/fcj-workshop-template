import { z } from "zod";
import { incidentSchema, type ReportRequest } from "../types";
import { defang } from "./security";

const sampleIds = { DEMO_1: "sample-1", DEMO_2: "sample-2", DEMO_3: "sample-3" };

export function reportBody(request: ReportRequest) {
  const idempotency_key = request.idempotency_key;
  return request.report_type === "TEXT"
    ? { text: request.text_content, idempotency_key }
    : { sample_id: sampleIds[request.sample_id], idempotency_key };
}

function record(value: unknown): Record<string, unknown> | undefined {
  if (value && typeof value === "object" && !Array.isArray(value))
    return value as Record<string, unknown>;
}

function normalizeIncident(value: unknown): unknown {
  const incident = record(value);
  if (!incident) return value;
  const normalized = { ...incident };

  const quality = record(incident.ocr_quality);
  if (
    quality &&
    typeof quality.mean_confidence === "number" &&
    typeof quality.acceptable === "boolean"
  ) {
    let extractionStatus = quality.acceptable ? "ACCEPTABLE" : "NEEDS_MORE_INFO";
    if (!quality.acceptable && typeof quality.qr_url_count === "number" && quality.qr_url_count > 0) {
      extractionStatus = "Đã đọc URL từ QR";
    }
    normalized.ocr_quality = incident.evidence_type === "IMAGE"
      ? {
          engine: typeof quality.engine === "string" ? quality.engine : "Textract",
          avg_confidence: quality.mean_confidence,
          normalized_chars: quality.normalized_chars,
          status: extractionStatus,
        }
      : null;
  }

  const findings = record(incident.deterministic_findings);
  if (findings && Array.isArray(findings.urls)) {
    const lookalikes = new Set(
      Array.isArray(findings.lookalike_domains) ? findings.lookalike_domains : [],
    );
    normalized.deterministic_findings = {
      ...findings,
      header_signals: findings.header_signals ?? findings.header_findings,
      extracted_urls: findings.extracted_urls ?? findings.urls.map((entry: unknown) => {
        const url = record(entry);
        if (!url) return entry;
        return { ...url, is_lookalike: lookalikes.has(url.registrable_domain || url.host) };
      }),
    };
  }

  const synthesis = record(incident.agent_synthesis);
  const evidence = Array.isArray(synthesis?.evidence_table) ? synthesis.evidence_table : [];
  const evidenceRows = evidence.map(record);
  const policy = record(incident.policy_evaluation);
  if (policy && Array.isArray(policy.triggered_rules)) {
    normalized.policy_evaluation = {
      ...policy,
      triggered_rules: policy.triggered_rules.map((rule: unknown) => {
        if (typeof rule !== "string") return rule;
        const row = evidenceRows.find((item) => item?.rule_id === rule);
        return { rule_id: rule, reason: row?.evidence_vi };
      }),
    };
  }

  if (Array.isArray(incident.proposed_actions)) {
    normalized.proposed_actions = incident.proposed_actions.map((entry: unknown) => {
      const action = record(entry);
      if (!action || action.display_target !== undefined || typeof action.target !== "string")
        return entry;
      return {
        ...action,
        display_target: action.type === "BLOCK_DOMAIN" ? defang(action.target) : action.target,
      };
    });
  }

  if (synthesis) {
    normalized.agent_synthesis = {
      ...synthesis,
      evidence_table: Array.isArray(synthesis.evidence_table) ? evidence.map((entry: unknown) => {
        const row = record(entry);
        if (!row || typeof row.rule_id !== "string") return entry;
        return { artifact: row.rule_id, value: row.evidence_vi, assessment: "" };
      }) : synthesis.evidence_table,
      rag_citations: Array.isArray(synthesis.rag_citations) ? synthesis.rag_citations.map((entry: unknown) => {
        const row = record(entry);
        if (!row || typeof row.source_id !== "string") return entry;
        const uri = record(record(row.location)?.s3Location)?.uri;
        const title = typeof uri === "string" ? uri.split("/").at(-1) : undefined;
        return { doc_id: row.source_id, title: title || row.source_id, excerpt: row.text };
      }) : synthesis.rag_citations,
    };
  }

  return normalized;
}

export const backendIncidentSchema = z.preprocess(normalizeIncident, incidentSchema);
