import { config } from "../config";
import { liveApi } from "./live-api";
import { mockApi } from "../mock/api";
export const api = config.useMock ? mockApi : liveApi;
