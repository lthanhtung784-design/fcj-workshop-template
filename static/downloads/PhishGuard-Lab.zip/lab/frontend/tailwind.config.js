/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: { brand: "#2563eb", ink: "#0f172a", canvas: "#f8fafc" },
      fontFamily: { sans: ["Inter Variable", "sans-serif"] },
    },
  },
  plugins: [],
};
