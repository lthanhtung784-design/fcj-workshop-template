"""Raw-reader boundary: email parsing, image OCR and structured PII masking."""
from email import policy as email_policy
from email.parser import BytesParser
from email.utils import getaddresses
from html.parser import HTMLParser
import hashlib
import os
import re
import unicodedata

from common import client, dumps, read_s3, task_wrapper, update_incident
from ocr import OCR_ENGINE, extract_image
from policy import canonical_host, normalize

EMAIL_ADDRESS = re.compile(r"(?i)\b[A-Z0-9._%+-]+@(?:[A-Z0-9-]+\.)+[A-Z]{2,}\b")
NUMBER = re.compile(r"(?<![\w/])\+?\d(?:[ .-]?\d){3,19}(?!\w)")
LABELLED = (
    ("CCCD", re.compile(r"(?i)(\bCCCD\s*[:#=]?\s*)(\d(?:[ .-]?\d){11})(?!\d)")),
    ("CMND", re.compile(r"(?i)(\bCMND\s*[:#=]?\s*)(\d(?:[ .-]?\d){8})(?!\d)")),
    ("BANK_ACCOUNT", re.compile(
        r"(?i)((?:\bSTK\b|s[ốo] TK|t[àa]i kho[ảa]n|\bTK\b|s[ốo] th[ẻe]|th[ẻe] ng[âa]n h[àa]ng)"
        r"[^\d\n]{0,30})(\d(?:[ .-]?\d){5,19})(?!\d)")),
    ("PHONE", re.compile(
        r"(?i)((?:SĐT|SDT|đi[ệe]n tho[ạa]i|s[ốo] m[ớo]i)\s*[:#=]?\s*)"
        r"((?:\+84|0)(?:[ .-]?\d){9,10})(?!\d)")),
    ("OTP", re.compile(r"(?i)((?:\bOTP\b|m[ãa] x[áa]c nh[ậa]n)\s*[:#=]?\s*)(\d{4,8})(?!\d)")),
)


class PlainHTML(HTMLParser):
    def __init__(self):
        super().__init__()
        self.text, self.skip = [], 0
    def handle_starttag(self, tag, attrs):
        if tag in {"script", "style"}:
            self.skip += 1
        if tag == "a" and not self.skip:
            url = dict(attrs).get("href") or ""
            if url.lower().startswith(("http://", "https://", "hxxp://", "hxxps://")):
                self.text.append(url)
    def handle_endtag(self, tag):
        if tag in {"script", "style"} and self.skip:
            self.skip -= 1
    def handle_data(self, data):
        if not self.skip:
            self.text.append(data)


class Redactor:
    def __init__(self):
        self.aliases = {}
        self.counts = {}
        self.numbers = {}

    def alias(self, kind, value):
        key = (kind, value)
        if key not in self.aliases:
            self.counts[kind] = self.counts.get(kind, 0) + 1
            self.aliases[key] = f"{kind}_{self.counts[kind]}"
        return self.aliases[key]

    def email(self, address):
        local, _, domain = address.rpartition("@")
        domain = canonical_host(domain)
        return self.alias("EMAIL_USER", f"{local.casefold()}@{domain}"), domain

    def number(self, kind, value):
        digits = re.sub(r"\D", "", value)
        canonical = "0" + digits[2:] if kind == "PHONE" and value.startswith("+84") else digits
        alias = self.alias(kind, canonical)
        self.numbers.setdefault(canonical, alias)
        return alias

    def unlabelled(self, match):
        value = match.group()
        digits = re.sub(r"\D", "", value)
        if digits in self.numbers:
            return self.numbers[digits]
        if (value.startswith("+84") and len(digits) in {11, 12}) or (digits.startswith("0") and len(digits) in {10, 11}):
            return self.number("PHONE", value)
        if re.fullmatch(r"\d{12}", value):
            return self.number("BANK_ACCOUNT", value)
        return value

    def text(self, text):
        text = unicodedata.normalize("NFC", text)
        parts = []
        start = 0
        for match in EMAIL_ADDRESS.finditer(text):
            parts.append(text[start:match.start()])
            try:
                alias, domain = self.email(match.group())
                parts.append(f"{alias}@{domain}")
            except (ValueError, UnicodeError):
                parts.append("EMAIL_REDACTED")
            start = match.end()
        parts.append(text[start:])
        # Resolve labelled values before masking unlabelled repetitions.
        for index in range(0, len(parts), 2):
            for kind, pattern in LABELLED:
                parts[index] = pattern.sub(lambda match: match[1] + self.number(kind, match[2]), parts[index])
        for index in range(0, len(parts), 2):
            parts[index] = NUMBER.sub(self.unlabelled, parts[index])
        return "".join(parts)


def redact(text):
    return Redactor().text(text)


def email_text(raw, redactor=None):
    redactor = redactor if redactor is not None else Redactor()
    message = BytesParser(policy=email_policy.default).parsebytes(raw)
    for part in message.walk():
        if part.get_content_type() == "message/rfc822":
            nested = part.get_payload()
            if isinstance(nested, list) and nested:
                message = nested[0]
                break
    claimed = {}
    for field, label in [("From", "from"), ("Reply-To", "reply_to"), ("Return-Path", "return_path")]:
        addresses = getaddresses(message.get_all(field, []))
        if len(addresses) == 1 and "@" in addresses[0][1]:
            try:
                alias, domain = redactor.email(addresses[0][1])
            except (ValueError, UnicodeError):
                continue
            claimed[f"{label}_domain"] = domain
            claimed[f"{label}_user"] = alias
    findings = []
    for field, flag in [("reply_to_domain", "HEADER_REPLY_TO_MISMATCH"),
                        ("return_path_domain", "HEADER_ENVELOPE_FROM_MISMATCH")]:
        if claimed.get("from_domain") and claimed.get(field) and claimed[field] != claimed["from_domain"]:
            findings.append(flag)
    parts = []
    for part in message.walk():
        if part.get_content_disposition() == "attachment" or part.is_multipart():
            continue
        if part.get_content_type() in {"text/plain", "text/html"}:
            try:
                value = part.get_content(errors="replace")
            except LookupError:
                value = (part.get_payload(decode=True) or b"").decode("utf-8", errors="replace")
            if part.get_content_type() == "text/html":
                parser = PlainHTML()
                parser.feed(str(value))
                value = " ".join(parser.text)
            parts.append(str(value))
    body = str(message.get("Subject", "")) + "\n" + "\n".join(parts)
    return body, {"source": "EMBEDDED_UNVERIFIED", "result": "INDETERMINATE", "claimed_headers": claimed}, findings


def handle(event):
    identifier = event["incident_id"]
    if not re.fullmatch(r"INC-[0-9a-f]{12}", identifier) or event["raw_s3_key"] != f"evidence/{identifier}/raw":
        raise ValueError("INVALID_EVIDENCE_REFERENCE")
    raw, info = read_s3(os.environ["EVIDENCE_BUCKET"], event["raw_s3_key"], event.get("raw_s3_version_id"))
    expected_hash = event.get("evidence_sha256") or info.get("Metadata", {}).get("sha256")
    if expected_hash and hashlib.sha256(raw).hexdigest() != expected_hash:
        raise ValueError("EVIDENCE_HASH_MISMATCH")
    auth = {"source": "NONE", "result": "INDETERMINATE", "claimed_headers": {}}
    flags, positions, confidence = [], [], 100.0
    redactor = Redactor()
    if event["evidence_type"] == "IMAGE":
        text, positions, confidence, qr_links = extract_image(raw)
    elif event["evidence_type"] == "EML":
        text, auth, flags = email_text(raw, redactor)
    elif event["evidence_type"] == "TEXT":
        text = raw.decode("utf-8-sig")
    else:
        raise ValueError("UNSUPPORTED_EVIDENCE")
    normalized_chars = len(normalize(text))
    quality = {"mean_confidence": round(confidence, 2), "normalized_chars": normalized_chars,
               "acceptable": confidence >= float(os.environ.get("OCR_CONFIDENCE_MIN", "85"))
               and normalized_chars >= int(os.environ.get("OCR_MIN_CHARS", "20"))}
    if event["evidence_type"] == "IMAGE":
        quality["engine"] = OCR_ENGINE
        quality["qr_url_count"] = len(qr_links)
        if qr_links:
            quality["engine"] += f" · QR: {len(qr_links)} URL"
            # Keep the OCR measurement specific to visible text.
            # Only legible OCR contributes to scoring when QR supplied the evidence.
            lines = [text] if quality["acceptable"] else []
            lines.extend(f"QR: {url}" for url in qr_links)
            text = "\n".join(lines)
    document = {"incident_id": identifier, "text": redactor.text(text), "email_auth": auth,
                "header_findings": flags, "ocr_quality": quality, "evidence_type": event["evidence_type"]}
    if positions:
        document["ocr_positions"] = positions
    key = f"sanitized/{identifier}/analysis.json"
    client("s3").put_object(Bucket=os.environ["SANITIZED_BUCKET"], Key=key,
        Body=dumps(document).encode("utf-8"), ContentType="application/json",
        ServerSideEncryption="aws:kms", SSEKMSKeyId=os.environ["DATA_KEY_ARN"])
    update_incident(identifier, status="TRIAGING", sanitized_s3_key=key, ocr_quality=quality,
                    email_auth=auth, raw_s3_version_id=info["VersionId"])
    return {"incident_id": identifier, "sanitized_s3_key": key, "ocr_quality": quality,
            "source_channel": event["source_channel"], "approval_timeout_seconds": event["approval_timeout_seconds"]}


def lambda_handler(event, context):
    return task_wrapper(handle, event)
