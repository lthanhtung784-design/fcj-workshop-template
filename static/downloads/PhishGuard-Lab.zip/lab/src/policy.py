"""Deterministic policy kernel; Spec v2.2 sections 7.4 and 7.5."""
import hashlib
import re
import unicodedata
from urllib.parse import urlsplit, urlunsplit

import tldextract

PSL = tldextract.TLDExtract(
    suffix_list_urls=(), cache_dir=None, include_psl_private_domains=True
)
OFFICIAL = {
    "techcombank": {"techcombank.com.vn"},
    "vietcombank": {"vietcombank.com.vn"},
    "acb": {"acb.com.vn"},
    "bidv": {"bidv.com.vn"},
}
ALLOWLIST = set().union(*OFFICIAL.values())
WEIGHTS = {
    "KNOWN_BLOCKED_IOC": 50, "BRAND_LOOKALIKE_DOMAIN": 40,
    "FINANCIAL_OR_OTP_REQUEST": 30, "EXEC_IMPERSONATION": 25,
    "URGENCY_PRESSURE": 10, "HEADER_ANOMALY": 10,
}


def normalize(text):
    text = unicodedata.normalize("NFD", text.lower().replace("đ", "d"))
    return " ".join("".join(c for c in text if not unicodedata.combining(c)).split())


def incident_id(source_intake_key):
    return "INC-" + hashlib.sha256(source_intake_key.encode("utf-8")).hexdigest()[:12]


def canonical_host(host):
    host = host.rstrip(".").lower().encode("idna").decode("ascii")
    if len(host) > 253 or any(
        not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", label)
        for label in host.split(".")
    ):
        raise ValueError("Invalid DNS hostname")
    return host


def registered(host):
    parts = PSL(canonical_host(host))
    return f"{parts.domain}.{parts.suffix}" if parts.domain and parts.suffix else ""


def lookalike(host):
    host = canonical_host(host)
    if registered(host) in ALLOWLIST:
        return False
    for label in host.split("."):
        tokens = [t.replace("0", "o").replace("1", "l").replace("rn", "m")
                  for t in label.split("-")]
        for brand in OFFICIAL:
            if (len(brand) >= 5 and brand in "".join(tokens)) or (
                len(brand) <= 4 and brand in tokens
            ):
                return True
    return False


def extract_urls(text):
    text = text.replace("[.]", ".")
    result = {}
    for candidate in re.findall(r"\b(?:https?|hxxps?)://[^\s<>\"']+", text, re.I):
        candidate = re.sub(r"^hxxp", "http", candidate, flags=re.I).rstrip(".,;:!?)]}")
        try:
            p = urlsplit(candidate)
            host = canonical_host(p.hostname or "")
            port = p.port
            netloc = host if port in (None, 443 if p.scheme.lower() == "https" else 80) else f"{host}:{port}"
            value = urlunsplit((p.scheme.lower(), netloc, p.path or "/", p.query, ""))
            result[value] = {"canonical_value": value, "host": host,
                             "registrable_domain": registered(host),
                             "display_value": value.replace("http", "hxxp", 1).replace(".", "[.]")}
        except (ValueError, UnicodeError):
            continue
    return list(result.values())


def valid_block_domain(target, urls):
    """Require a canonical registrable domain already present in the evidence."""
    if not isinstance(target, str) or target in ALLOWLIST:
        return False
    try:
        if target != canonical_host(target) or registered(target) != target:
            return False
    except (ValueError, UnicodeError):
        return False
    return any(url.get("registrable_domain") == target for url in urls)


def evaluate(text, *, header_anomaly=False, blocklist=None, mode="DRY_RUN", urls=None):
    if mode not in {"DRY_RUN", "INTERNAL_LIST"}:
        raise ValueError("mode must be DRY_RUN or INTERNAL_LIST")
    blocklist = blocklist or {}
    n = normalize(text)
    urls = extract_urls(text) if urls is None else urls
    transfer = bool(re.search(r"chuyen\s+(?:khoan|tien)", n))
    sensitive = transfer or bool(re.search(
        r"(?:cung cap|gui|nhap|tiet lo|chia se).{0,50}(?:otp|mat khau|ma xac nhan)"
        r"|quet.{0,25}qr.{0,30}nhan tien", n))
    warning = bool(re.search(
        r"(?:khong|dung).{0,25}(?:cung cap|gui|chia se|tiet lo).{0,25}(?:otp|mat khau|ma xac nhan)", n))
    financial = sensitive and not (warning and not urls and not transfer)
    executive = bool(re.search(r"\b(?:giam doc|ceo|chu tich)\b", n))
    off_process = bool(re.search(
        r"ngoai quy trinh|bo qua quy trinh|khong can phe duyet|tai khoan (?:moi|la)", n))
    impersonation = executive and off_process and (transfer or "doi tai khoan" in n)
    urgency = bool(re.search(r"\b(?:gap|khan cap|ngay lap tuc)\b|trong \d+ phut", n))
    flagged = sorted({u["registrable_domain"] or u["host"] for u in urls if lookalike(u["host"])})
    blocked = sorted({u["registrable_domain"] or u["host"] for u in urls if any(
        blocklist.get(key) in {"SEED", "APPROVED_CONFIRMED"}
        for key in (u["canonical_value"], u["host"], u["registrable_domain"])
    )})
    external = any(u["registrable_domain"] not in ALLOWLIST for u in urls)
    conditions = [bool(blocked), bool(flagged), financial, impersonation,
                  urgency, header_anomaly and (financial or external)]
    triggered = [rule for rule, active in zip(WEIGHTS, conditions) if active]
    score = min(100, sum(WEIGHTS[r] for r in triggered))
    severity = "CRITICAL" if score >= 75 else "HIGH" if score >= 50 else "MEDIUM" if score >= 25 else "LOW"
    actions = []
    if score >= 50:
        for target in sorted(set(flagged + blocked)):
            if valid_block_domain(target, urls):
                actions.append({"type": "BLOCK_DOMAIN", "target": target})
        if impersonation:
            actions.append({"type": "FINANCE_VERIFICATION_ALERT", "target": "FINANCE"})
    for i, action in enumerate(actions, 1):
        action.update(action_id=f"ACT-{i:03d}", mode=mode, proposal_version=1)
    injection = bool(re.search(
        r"ignore.{0,50}instructions|bo qua.{0,40}(?:luat|chi dan)|dat.{0,15}diem.{0,10}0", n))
    return {
        "policy_evaluation": {"risk_score": score, "severity": severity, "triggered_rules": triggered},
        "deterministic_findings": {"urls": urls, "lookalike_domains": flagged, "blocked_domains": blocked},
        "security_flags": ["PROMPT_INJECTION_DETECTED"] if injection else [],
        "proposed_actions": actions,
        "requires_manual_review": score >= 50 and not actions,
    }
