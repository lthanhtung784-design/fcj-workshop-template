## Chạy website FCAJ trên Windows trước khi push

Website tài liệu dùng Hugo và mở được trên máy không đăng nhập AWS. Để đăng nhập Reporter và gửi incident, mở địa chỉ CloudFront của ứng dụng. Hai website phục vụ hai mục đích khác nhau.

### 1. Giải nén đúng thư mục

Tải PhishGuard-FCAJ-GitHub.zip vào Downloads. Mở PowerShell, dùng một thư mục trống để giữ bản đang chỉnh sửa của bạn.

```powershell
$siteZip = "$env:USERPROFILE\Downloads\PhishGuard-FCAJ-GitHub.zip"
$dest = "$env:USERPROFILE\Projects\PhishGuard-docs-preview"
Expand-Archive -LiteralPath $siteZip -DestinationPath $dest -ErrorAction Stop
Set-Location "$dest\fcaj-workshop"
Test-Path .\config.toml
Test-Path .\themes\hugo-theme-learn
```

Cả hai dòng phải trả True. Nếu đã giải nén qua File Explorer, mở PowerShell tại thư mục chứa config.toml rồi tiếp tục. Nếu trình duyệt đã thêm (1) vào tên ZIP, sửa tên ở dòng đầu.

### 2. Cài Hugo Extended 0.134.3

Trên Windows x64, tải bản portable cùng phiên bản với GitHub Actions. Chạy trong cùng cửa sổ, không cần quyền Administrator.

```powershell
$version = '0.134.3'
$toolsDir = "$env:LOCALAPPDATA\Programs\HugoExtended\$version"
$hugoZip = "$env:TEMP\hugo_extended_${version}_windows-amd64.zip"
$release = "https://github.com/gohugoio/hugo/releases/download/v$version"
Invoke-WebRequest "$release/hugo_extended_${version}_windows-amd64.zip" -OutFile $hugoZip -ErrorAction Stop
Expand-Archive -LiteralPath $hugoZip -DestinationPath $toolsDir -Force -ErrorAction Stop
$hugo = Join-Path $toolsDir 'hugo.exe'
& $hugo version
```

Kiểm tra kết quả có v0.134.3 và extended. Có thể tải cùng ZIP từ trang release bằng trình duyệt và giải nén thủ công nếu PowerShell bị chặn tải. Bản binary đã giải nén sử dụng được ở các lần sau.

### 3. Mở trang và xem thay đổi

```powershell
& $hugo server --disableFastRender --bind 127.0.0.1 --port 1313
```

Giữ cửa sổ đang chạy. Mở http://localhost:1313/ cho tiếng Anh hoặc http://localhost:1313/vi/ cho tiếng Việt. Chọn Workshop → WAF, RAG và giải mã QR. Sửa một tiêu đề trong content rồi lưu, kiểm tra trình duyệt tự tải lại. Nhấn Ctrl+C để dừng. Nếu cổng bận, thay 1313 bằng 1314 trong cả câu lệnh và địa chỉ trình duyệt. Nếu mở PowerShell mới, quay lại thư mục có config.toml và đặt lại `$hugo = "$env:LOCALAPPDATA\Programs\HugoExtended\0.134.3\hugo.exe"`.

### 4. Kiểm tra bản xuất trước khi push

```powershell
& $hugo --minify
if ($LASTEXITCODE -ne 0) { throw 'Hugo build failed.' }
Test-Path .\public\vi\5-workshop\index.html
```

Kết quả cuối là True. Commit nguồn trên main theo phần GitHub Pages của README. GitHub Actions tạo lại thư mục public khi xuất bản. Theme đã có trong ZIP. Nếu muốn dùng Git để push và máy chưa có Git, cài bằng `winget install --id Git.Git -e`, mở lại PowerShell rồi chạy `git --version`.

[Tải Hugo v0.134.3](https://github.com/gohugoio/hugo/releases/tag/v0.134.3) · [Cài Hugo cho Windows](https://gohugo.io/installation/windows/)
